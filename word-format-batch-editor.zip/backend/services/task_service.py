"""Task service - manages batch processing tasks."""

import os
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from sqlalchemy.orm import Session

from backend.config import get_config
from backend.models.document import Document
from backend.models.task import Task
from backend.schemas.task import TaskCreate, TaskStatus, ProcessResult, Modification
from backend.services.document_service import get_document


def create_task(data: TaskCreate, db: Session) -> Task:
    """Create a new batch processing task."""
    task = Task(
        id=str(uuid.uuid4()),
        name=data.name or f"Batch-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}",
        status="PENDING",
        total_documents=len(data.document_ids),
        config_json=data.model_dump(),
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


def get_task(task_id: str, db: Session) -> Optional[Task]:
    return db.query(Task).filter(Task.id == task_id).first()


def list_tasks(db: Session, page: int = 1, size: int = 20) -> tuple:
    query = db.query(Task).order_by(Task.created_at.desc())
    total = query.count()
    tasks = query.offset((page - 1) * size).limit(size).all()
    return tasks, total


def update_task_progress(
    task_id: str, db: Session,
    processed: int = None, success: int = None,
    error: int = None, skipped: int = None,
    status: str = None, error_message: str = None,
    result_json: dict = None,
):
    """Update task progress."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if task is None:
        return

    if processed is not None:
        task.processed_documents = processed
    if success is not None:
        task.success_count = success
    if error is not None:
        task.error_count = error
    if skipped is not None:
        task.skipped_count = skipped
    if status:
        task.status = status
        if status == "RUNNING" and task.started_at is None:
            task.started_at = datetime.utcnow()
        if status in ("DONE", "FAILED", "CANCELLED"):
            task.completed_at = datetime.utcnow()
    if error_message is not None:
        task.error_message = error_message
    if result_json is not None:
        task.result_json = result_json

    # Calculate progress
    if task.total_documents > 0:
        task.progress = task.processed_documents / task.total_documents

    db.commit()


def pause_task(task_id: str, db: Session) -> bool:
    task = db.query(Task).filter(Task.id == task_id).first()
    if task and task.status == "RUNNING":
        task.status = "PAUSED"
        db.commit()
        return True
    return False


def resume_task(task_id: str, db: Session) -> bool:
    task = db.query(Task).filter(Task.id == task_id).first()
    if task and task.status == "PAUSED":
        task.status = "RUNNING"
        db.commit()
        return True
    return False


def cancel_task(task_id: str, db: Session) -> bool:
    task = db.query(Task).filter(Task.id == task_id).first()
    if task and task.status in ("PENDING", "RUNNING", "PAUSED"):
        task.status = "CANCELLED"
        task.completed_at = datetime.utcnow()
        db.commit()
        return True
    return False


def rollback_task(task_id: str, node_ids: List[str], db: Session) -> int:
    """Rollback modifications from a task. Returns count of rolled back files."""
    task = db.query(Task).filter(Task.id == task_id).first()
    if task is None:
        return 0

    config = get_config()
    storage = Path(config.storage.base_path)
    rolled_back = 0

    config_data = task.config_json or {}
    document_ids = config_data.get("document_ids", [])

    for doc_id in document_ids:
        doc = db.query(Document).filter(Document.id == doc_id).first()
        if doc is None or doc.snapshot_path is None:
            continue

        if os.path.exists(doc.snapshot_path):
            # Restore from snapshot
            if doc.processed_path and os.path.exists(doc.processed_path):
                os.remove(doc.processed_path)
            shutil.copy2(doc.snapshot_path, doc.original_path)
            doc.status = "UPLOADED"
            doc.processed_path = None
            rolled_back += 1

    db.commit()
    return rolled_back
