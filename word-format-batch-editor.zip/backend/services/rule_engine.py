"""Rule engine - matches format rules to document nodes."""

import ast
from typing import Dict, List, Optional
from backend.schemas.format_spec import FormatRule, RuleCondition
from backend.schemas.document import DocumentStructure, DocumentNode


def match_rules(
    structure: DocumentStructure,
    rules: List[FormatRule],
) -> Dict[str, List[FormatRule]]:
    """Match rules to document nodes. Returns {node_id: [matched_rules]} sorted by priority."""
    result: Dict[str, List[FormatRule]] = {}

    enabled_rules = [r for r in rules if r.enabled]
    enabled_rules.sort(key=lambda r: r.priority, reverse=True)

    for node_id, node in structure.nodes.items():
        matched = []
        for rule in enabled_rules:
            if _evaluate_condition(rule.condition, node, structure):
                matched.append(rule)
        if matched:
            result[node_id] = matched

    return result


def _evaluate_condition(
    condition: RuleCondition,
    node: DocumentNode,
    structure: DocumentStructure,
) -> bool:
    """Evaluate a single condition against a node."""

    # Node type filter
    if condition.node_type and node.type != condition.node_type:
        return False

    # Level filter
    if condition.level is not None and node.level != condition.level:
        return False

    # Style name contains
    if condition.style_name_contains:
        if condition.style_name_contains.lower() not in node.style_name.lower():
            return False

    # Content contains
    if condition.content_contains:
        if condition.content_contains.lower() not in node.content_preview.lower():
            return False

    # Section title contains
    if condition.section_title_contains:
        section_node = structure.nodes.get(node.section_id)
        if section_node is None:
            return False
        if condition.section_title_contains.lower() not in section_node.content_preview.lower():
            return False

    # Table-specific conditions
    if condition.table_min_rows is not None or condition.table_max_rows is not None:
        if node.type != "table" or node.table_info is None:
            return False
        if condition.table_min_rows is not None and node.table_info.rows < condition.table_min_rows:
            return False
        if condition.table_max_rows is not None and node.table_info.rows > condition.table_max_rows:
            return False

    # Custom expression (safe eval)
    if condition.custom_expression:
        if not _safe_eval(condition.custom_expression, node, structure):
            return False

    return True


def _safe_eval(expression: str, node: DocumentNode, structure: DocumentStructure) -> bool:
    """Safely evaluate a custom expression against a node.
    Only allows access to node attributes, no imports or dangerous operations."""
    # Build safe context
    context = {
        "type": node.type,
        "level": node.level,
        "style_name": node.style_name,
        "content_preview": node.content_preview,
        "section_title": structure.nodes.get(node.section_id, node).content_preview,
        "table_rows": node.table_info.rows if node.table_info else 0,
        "table_cols": node.table_info.cols if node.table_info else 0,
    }

    # Validate expression using AST - only allow simple comparisons
    try:
        tree = ast.parse(expression, mode="eval")
        # Check for forbidden constructs
        for node_ast in ast.walk(tree):
            if isinstance(node_ast, (ast.Import, ast.ImportFrom)):
                return False
            if isinstance(node_ast, ast.Call):
                # Only allow built-in functions
                if isinstance(node_ast.func, ast.Name):
                    if node_ast.func.id not in ("len", "int", "float", "str", "bool"):
                        return False
                else:
                    return False
            if isinstance(node_ast, ast.Attribute):
                # Only allow access to our context variables
                pass

        return bool(eval(expression, {"__builtins__": {}}, context))
    except Exception:
        return False


def validate_rule(rule: FormatRule) -> List[str]:
    """Validate a format rule. Returns list of errors (empty if valid)."""
    errors = []

    if not rule.id:
        errors.append("Rule ID is required")
    if not rule.name:
        errors.append("Rule name is required")

    # Validate custom expression if present
    if rule.condition.custom_expression:
        try:
            tree = ast.parse(rule.condition.custom_expression, mode="eval")
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    errors.append("Import statements are not allowed in custom expressions")
                    break
        except SyntaxError as e:
            errors.append(f"Invalid expression syntax: {e}")

    return errors
