"""Document structure parser - parses .docx into DocumentStructure."""

import uuid
from typing import Dict, List, Optional, Tuple
from lxml import etree
from backend.core.ooxml_reader import OOXMLReader
from backend.core.ooxml_writer import NSMAP, twips_to_pt
from backend.core.styles_parser import parse_styles, resolve_style_chain, StyleInfo
from backend.core.numbering_parser import parse_numbering
from backend.schemas.document import (
    DocumentStructure, DocumentNode, TableInfo, MergedCell,
    SectionInfo, StructureStats, FormatSpec,
)


def parse_document_structure(file_path: str, document_id: str) -> DocumentStructure:
    """Parse a .docx file into a DocumentStructure model."""
    with OOXMLReader(file_path) as reader:
        doc_xml = reader.get_document_xml()
        styles_xml = reader.get_styles_xml()
        numbering_xml = reader.get_numbering_xml()

        styles = parse_styles(styles_xml) if styles_xml is not None else {}
        numbering = parse_numbering(numbering_xml) if numbering_xml is not None else None

        w = NSMAP["w"]
        body = doc_xml.find(f"{{{w}}}body")
        if body is None:
            return DocumentStructure(
                document_id=document_id, total_pages=0,
                sections=[], nodes={}, root_node_ids=[], statistics=StructureStats()
            )

        nodes: Dict[str, DocumentNode] = {}
        root_node_ids: List[str] = []
        sections: List[SectionInfo] = []
        stats = StructureStats()

        # Track heading sections for building section tree
        heading_stack: List[Tuple[int, str, str]] = []  # (level, section_id, node_id)

        def make_node_id() -> str:
            return str(uuid.uuid4())

        def get_section_id() -> str:
            """Get current section ID from the nearest ancestor heading."""
            if heading_stack:
                return heading_stack[-1][1]
            return "default"

        def get_section_title() -> str:
            """Get current section title."""
            if heading_stack:
                return heading_stack[-1][2]
            return ""

        def extract_format(para_el) -> FormatSpec:
            """Extract direct formatting from a paragraph/run element."""
            fmt = FormatSpec()

            # Paragraph properties
            ppr = para_el.find(f"{{{w}}}pPr")
            if ppr is not None:
                # Alignment
                jc = ppr.find(f"{{{w}}}jc")
                if jc is not None:
                    val = jc.get(f"{{{w}}}val", "")
                    align_map = {
                        "left": "left", "center": "center", "right": "right",
                        "both": "justify", "distribute": "distribute",
                    }
                    fmt.alignment = align_map.get(val)

                # Spacing
                spacing = ppr.find(f"{{{w}}}spacing")
                if spacing is not None:
                    before = spacing.get(f"{{{w}}}before")
                    after = spacing.get(f"{{{w}}}after")
                    line = spacing.get(f"{{{w}}}line")
                    line_rule = spacing.get(f"{{{w}}}lineRule")
                    if before:
                        try:
                            fmt.space_before = int(before) / 20.0
                        except ValueError:
                            pass
                    if after:
                        try:
                            fmt.space_after = int(after) / 20.0
                        except ValueError:
                            pass
                    if line:
                        try:
                            line_val = int(line)
                            if line_rule == "exact":
                                fmt.line_spacing = line_val / 20.0
                            else:
                                fmt.line_spacing = line_val / 240.0
                        except ValueError:
                            pass

                # Indentation
                ind = ppr.find(f"{{{w}}}ind")
                if ind is not None:
                    first = ind.get(f"{{{w}}}firstLine")
                    if first:
                        try:
                            fmt.first_line_indent = int(first) / 20.0
                        except ValueError:
                            pass

            # Run properties (from first run or style)
            run = para_el.find(f"{{{w}}}r")
            if run is not None:
                rpr = run.find(f"{{{w}}}rPr")
                if rpr is not None:
                    fmt = _extract_run_format(rpr, fmt)

            return fmt

        def _extract_run_format(rpr, fmt: FormatSpec) -> FormatSpec:
            """Extract run-level formatting."""
            fonts = rpr.find(f"{{{w}}}rFonts")
            if fonts is not None:
                fmt.font_cn = fonts.get(f"{{{w}}}eastAsia")
                fmt.font_en = fonts.get(f"{{{w}}}ascii")

            sz = rpr.find(f"{{{w}}}sz")
            if sz is not None:
                try:
                    fmt.font_size = int(sz.get(f"{{{w}}}val", "0")) / 2.0
                except ValueError:
                    pass

            color = rpr.find(f"{{{w}}}color")
            if color is not None:
                val = color.get(f"{{{w}}}val", "")
                if val and val != "auto":
                    fmt.font_color = f"#{val}"

            b = rpr.find(f"{{{w}}}b")
            if b is not None:
                val = b.get(f"{{{w}}}val", "true")
                fmt.bold = val.lower() != "false"

            i = rpr.find(f"{{{w}}}i")
            if i is not None:
                val = i.get(f"{{{w}}}val", "true")
                fmt.italic = val.lower() != "false"

            u = rpr.find(f"{{{w}}}u")
            if u is not None:
                val = u.get(f"{{{w}}}val", "")
                if val in ("single", "double", "wave"):
                    fmt.underline = val

            return fmt

        def process_element(el, parent_id=None):
            """Recursively process body elements."""
            tag = etree.QName(el.tag).localname

            if tag == "p":
                _process_paragraph(el, parent_id)
            elif tag == "tbl":
                _process_table(el, parent_id)
            elif tag == "sdt":
                # Structured document tag - process content
                content = el.find(f"{{{w}}}sdtContent")
                if content is not None:
                    for child in content:
                        process_element(child, parent_id)

        def _process_paragraph(para_el, parent_id=None):
            """Process a paragraph element."""
            node_id = make_node_id()

            # Determine type and level
            ppr = para_el.find(f"{{{w}}}pPr")
            node_type = "paragraph"
            level = 0
            style_name = ""
            num_id = None
            ilvl = None

            if ppr is not None:
                # Style
                pstyle = ppr.find(f"{{{w}}}pStyle")
                if pstyle is not None:
                    style_name = pstyle.get(f"{{{w}}}val", "")

                # Heading detection
                outline = ppr.find(f"{{{w}}}outlineLvl")
                if outline is not None:
                    try:
                        level = int(outline.get(f"{{{w}}}val", "0")) + 1
                        node_type = "heading"
                    except ValueError:
                        pass

                if node_type != "heading" and style_name.lower().startswith("heading"):
                    node_type = "heading"
                    try:
                        level = int(style_name.lower().replace("heading", "").strip())
                    except ValueError:
                        level = 1

                # List detection
                numpr = ppr.find(f"{{{w}}}numPr")
                if numpr is not None:
                    num_id_el = numpr.find(f"{{{w}}}numId")
                    ilvl_el = numpr.find(f"{{{w}}}ilvl")
                    if num_id_el is not None:
                        try:
                            num_id = int(num_id_el.get(f"{{{w}}}val", "0"))
                        except ValueError:
                            pass
                    if ilvl_el is not None:
                        try:
                            ilvl = int(ilvl_el.get(f"{{{w}}}val", "0"))
                        except ValueError:
                            pass
                    if num_id is not None:
                        node_type = "list_item"
                        level = ilvl if ilvl is not None else 0

                # Also detect list by style name (python-docx List Bullet/Number styles)
                if node_type == "paragraph" and style_name:
                    sn = style_name.lower()
                    if "list" in sn:
                        node_type = "list_item"
                        if "bullet" in sn:
                            level = 0
                        elif "number" in sn:
                            level = 0

            # Extract text content
            text_parts = []
            for run in para_el.findall(f"{{{w}}}r"):
                for t in run.findall(f"{{{w}}}t"):
                    if t.text:
                        text_parts.append(t.text)
            content = "".join(text_parts)[:50]

            # Page/section break detection
            if ppr is not None:
                sect = ppr.find(f"{{{w}}}sectPr")
                if sect is not None:
                    # Section break - still create the paragraph node
                    pass

            # Format
            fmt = extract_format(para_el)

            # Apply style-based formatting
            if style_name and style_name in styles:
                resolved = resolve_style_chain(styles, style_name)
                if "font_cn" in resolved and not fmt.font_cn:
                    fmt.font_cn = resolved["font_cn"]
                if "font_en" in resolved and not fmt.font_en:
                    fmt.font_en = resolved["font_en"]
                if "font_size" in resolved and not fmt.font_size:
                    fmt.font_size = resolved["font_size"]
                if "bold" in resolved and fmt.bold is None:
                    fmt.bold = resolved["bold"]
                if "italic" in resolved and fmt.italic is None:
                    fmt.italic = resolved["italic"]

            section_id = get_section_id()

            # Update heading stack
            if node_type == "heading":
                while heading_stack and heading_stack[-1][0] >= level:
                    heading_stack.pop()
                heading_stack.append((level, node_id, content))
                section_id = node_id

            node = DocumentNode(
                id=node_id, type=node_type, level=level,
                parent_id=parent_id, children_ids=[],
                section_id=section_id, content_preview=content,
                style_name=style_name, xml_xpath=_get_xpath(para_el),
                current_format=fmt,
            )
            nodes[node_id] = node

            if parent_id and parent_id in nodes:
                nodes[parent_id].children_ids.append(node_id)
            else:
                root_node_ids.append(node_id)

            # Update stats
            if node_type == "heading":
                stats.heading_count += 1
            elif node_type == "paragraph":
                stats.paragraph_count += 1
            elif node_type == "list_item":
                stats.list_count += 1

        def _process_table(tbl_el, parent_id=None):
            """Process a table element."""
            node_id = make_node_id()

            # Parse grid
            grid = tbl_el.find(f"{{{w}}}tblGrid")
            cols = 0
            if grid is not None:
                cols = len(grid.findall(f"{{{w}}}gridCol"))

            # Parse rows and cells
            rows = tbl_el.findall(f"{{{w}}}tr")
            row_count = len(rows)
            merged_cells = []
            has_header = False

            for r_idx, tr in enumerate(rows):
                cells = tr.findall(f"{{{w}}}tc")
                col_idx = 0
                for cell in cells:
                    # Check horizontal merge
                    grid_span_el = cell.find(f"{{{w}}}tcPr/{{{w}}}gridSpan")
                    col_span = 1
                    if grid_span_el is not None:
                        try:
                            col_span = int(grid_span_el.get(f"{{{w}}}val", "1"))
                        except ValueError:
                            pass

                    # Check vertical merge
                    vmerge_el = cell.find(f"{{{w}}}tcPr/{{{w}}}vMerge")
                    row_span = 1
                    if vmerge_el is not None:
                        merge_val = vmerge_el.get(f"{{{w}}}val", "")
                        if merge_val == "restart" or merge_val == "":
                            # Count subsequent vMerge cells
                            row_span = _count_vmerge(rows, r_idx, col_idx)
                        else:
                            # This cell is merged with above
                            col_idx += col_span
                            continue

                    if col_span > 1 or row_span > 1:
                        merged_cells.append(MergedCell(
                            row=r_idx, col=col_idx,
                            row_span=row_span, col_span=col_span,
                        ))

                    col_idx += col_span

                # Check for header row
                if r_idx == 0:
                    tr_pr = tr.find(f"{{{w}}}trPr")
                    if tr_pr is not None:
                        header_el = tr_pr.find(f"{{{w}}}tblHeader")
                        if header_el is not None:
                            has_header = True

            # Nested tables
            nested = []
            for cell in tbl_el.iter(f"{{{w}}}tc"):
                for nested_tbl in cell.findall(f"{{{w}}}tbl"):
                    nested_id = make_node_id()
                    nested.append(nested_id)

            table_info = TableInfo(
                rows=row_count, cols=cols or 1,
                merged_cells=merged_cells, nested_tables=nested,
                has_header_row=has_header,
            )

            node = DocumentNode(
                id=node_id, type="table", level=0,
                parent_id=parent_id, children_ids=[],
                section_id=get_section_id(), content_preview=f"[Table {row_count}×{cols}]",
                style_name="", xml_xpath=_get_xpath(tbl_el),
                current_format=FormatSpec(), table_info=table_info,
            )
            nodes[node_id] = node

            if parent_id and parent_id in nodes:
                nodes[parent_id].children_ids.append(node_id)
            else:
                root_node_ids.append(node_id)

            stats.table_count += 1

        def _count_vmerge(rows, start_row, col_idx):
            """Count consecutive vertically merged cells."""
            count = 1
            for r in range(start_row + 1, len(rows)):
                cells = rows[r].findall(f"{{{w}}}tc")
                if col_idx >= len(cells):
                    break
                cell = cells[col_idx]
                vmerge = cell.find(f"{{{w}}}tcPr/{{{w}}}vMerge")
                if vmerge is not None:
                    merge_val = vmerge.get(f"{{{w}}}val", "")
                    if merge_val == "restart":
                        break
                    count += 1
                else:
                    break
            return count

        def _get_xpath(el):
            """Get simplified XPath for an element."""
            parts = []
            current = el
            while current is not None:
                tag = etree.QName(current.tag).localname
                parts.append(tag)
                current = current.getparent()
            return "/" + "/".join(reversed(parts))

        # Process all body elements
        for child in body:
            process_element(child)

        # Build section tree
        sections = _build_section_tree(nodes, root_node_ids)

        stats.total_nodes = len(nodes)

        return DocumentStructure(
            document_id=document_id,
            total_pages=max(1, stats.paragraph_count // 40 + 1),  # Rough estimate
            sections=sections,
            nodes=nodes,
            root_node_ids=root_node_ids,
            statistics=stats,
        )


def _build_section_tree(nodes: Dict[str, DocumentNode], root_ids: List[str]) -> List[SectionInfo]:
    """Build a hierarchical section tree from heading nodes."""
    sections: List[SectionInfo] = []
    stack: List[SectionInfo] = []

    for nid in root_ids:
        node = nodes.get(nid)
        if node is None:
            continue
        if node.type == "heading":
            section = SectionInfo(
                id=node.id, title=node.content_preview,
                level=node.level, node_id=node.id, children=[],
            )
            # Find parent section
            while stack and stack[-1].level >= node.level:
                stack.pop()
            if stack:
                stack[-1].children.append(section)
            else:
                sections.append(section)
            stack.append(section)

    return sections
