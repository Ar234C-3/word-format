"""Format engine - applies formatting rules to .docx documents."""

import copy
import uuid
from datetime import datetime
from typing import List, Optional, Tuple
from lxml import etree

from backend.core.ooxml_reader import OOXMLReader
from backend.core.ooxml_writer import OOXMLWriter, NSMAP, pt_to_twips, pt_to_half_pt
from backend.schemas.format_spec import FormatSpec, FormatRule, RuleAction
from backend.schemas.document import DocumentStructure, DocumentNode
from backend.schemas.task import Modification
from backend.services.structure_parser import parse_document_structure


def apply_format_rules(
    file_path: str,
    output_path: str,
    rules: List[FormatRule],
    document_id: str,
    snapshot_path: Optional[str] = None,
) -> Tuple[str, List[Modification]]:
    """Apply format rules to a document. Returns (output_path, modifications)."""
    import shutil

    # Create snapshot first
    if snapshot_path:
        shutil.copy2(file_path, snapshot_path)

    # Parse structure
    structure = parse_document_structure(file_path, document_id)

    # Match rules to nodes
    from backend.services.rule_engine import match_rules
    node_rules = match_rules(structure, rules)

    # Apply modifications
    modifications: List[Modification] = []

    with OOXMLWriter(file_path, output_path) as writer:
        # Read document XML
        with OOXMLReader(file_path) as reader:
            doc_xml = reader.get_document_xml()

        w = NSMAP["w"]

        # Process each node that has matched rules
        body = doc_xml.find(f"{{{w}}}body")
        if body is not None:
            # Build a mapping from element to node by iterating in order
            element_node_map = _build_element_node_map(body, w, structure)

            for el, node in element_node_map:
                matched_rules = node_rules.get(node.id, [])
                if not matched_rules:
                    continue

                # Apply rules in priority order (highest first)
                for rule in matched_rules:
                    mod = _apply_action_to_element(el, rule, node, w)
                    modifications.extend(mod)

        # Save modified XML
        writer.set_xml("word/document.xml", doc_xml)
        writer.save()

    return output_path, modifications


def _build_element_node_map(body, w: str, structure):
    """Build ordered list of (element, node) pairs by iterating body children.
    Matches the same order as structure_parser."""
    pairs = []
    node_iter = iter(structure.root_node_ids)

    def match_element(el):
        tag = etree.QName(el.tag).localname
        if tag == "p":
            nid = next(node_iter, None)
            if nid and nid in structure.nodes:
                pairs.append((el, structure.nodes[nid]))
        elif tag == "tbl":
            nid = next(node_iter, None)
            if nid and nid in structure.nodes:
                pairs.append((el, structure.nodes[nid]))
        elif tag == "sdt":
            content = el.find(f"{{{w}}}sdtContent")
            if content is not None:
                for child in content:
                    match_element(child)

    for child in body:
        match_element(child)

    return pairs


def _apply_action_to_element(
    el: etree._Element,
    rule: FormatRule,
    node: DocumentNode,
    w: str,
) -> List[Modification]:
    """Apply a rule's action to an XML element."""
    modifications = []
    action = rule.action
    now = datetime.utcnow()

    # Get or create pPr (paragraph properties)
    ppr = el.find(f"{{{w}}}pPr")
    if ppr is None and _needs_ppr(action):
        ppr = etree.SubElement(el, f"{{{w}}}pPr")
        # Insert as first child
        el.insert(0, ppr)

    # Get or create rPr in first run
    rpr = None
    run = el.find(f"{{{w}}}r")
    if run is not None:
        rpr = run.find(f"{{{w}}}rPr")
        if rpr is None and _needs_rpr(action):
            rpr = etree.SubElement(run, f"{{{w}}}rPr")
            run.insert(0, rpr)

    # Apply font settings
    if action.font_cn or action.font_en:
        if rpr is not None:
            fonts = rpr.find(f"{{{w}}}rFonts")
            if fonts is None:
                fonts = etree.SubElement(rpr, f"{{{w}}}rFonts")
            before_cn = fonts.get(f"{{{w}}}eastAsia", "")
            before_en = fonts.get(f"{{{w}}}ascii", "")
            if action.font_cn:
                fonts.set(f"{{{w}}}eastAsia", action.font_cn)
            if action.font_en:
                fonts.set(f"{{{w}}}ascii", action.font_en)
            modifications.append(Modification(
                node_path=node.xml_xpath, rule_id=rule.id,
                property_name="font_cn", before_value=before_cn,
                after_value=action.font_cn or before_cn, timestamp=now,
            ))
            modifications.append(Modification(
                node_path=node.xml_xpath, rule_id=rule.id,
                property_name="font_en", before_value=before_en,
                after_value=action.font_en or before_en, timestamp=now,
            ))

    # Apply font size
    if action.font_size and rpr is not None:
        sz = rpr.find(f"{{{w}}}sz")
        if sz is None:
            sz = etree.SubElement(rpr, f"{{{w}}}sz")
        before = sz.get(f"{{{w}}}val", "24")
        sz.set(f"{{{w}}}val", str(pt_to_half_pt(action.font_size)))
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="font_size", before_value=float(before) / 2,
            after_value=action.font_size, timestamp=now,
        ))

    # Apply bold
    if action.bold is not None and rpr is not None:
        b = rpr.find(f"{{{w}}}b")
        before = False
        if b is not None:
            before = b.get(f"{{{w}}}val", "true").lower() != "false"
        else:
            b = etree.SubElement(rpr, f"{{{w}}}b")
        if action.bold:
            b.set(f"{{{w}}}val", "true")
        else:
            b.set(f"{{{w}}}val", "false")
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="bold", before_value=before,
            after_value=action.bold, timestamp=now,
        ))

    # Apply italic
    if action.italic is not None and rpr is not None:
        i = rpr.find(f"{{{w}}}i")
        before = False
        if i is not None:
            before = i.get(f"{{{w}}}val", "true").lower() != "false"
        else:
            i = etree.SubElement(rpr, f"{{{w}}}i")
        if action.italic:
            i.set(f"{{{w}}}val", "true")
        else:
            i.set(f"{{{w}}}val", "false")
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="italic", before_value=before,
            after_value=action.italic, timestamp=now,
        ))

    # Apply font color
    if action.font_color and rpr is not None:
        color = rpr.find(f"{{{w}}}color")
        before = ""
        if color is not None:
            before = color.get(f"{{{w}}}val", "")
        else:
            color = etree.SubElement(rpr, f"{{{w}}}color")
        hex_val = action.font_color.lstrip("#")
        color.set(f"{{{w}}}val", hex_val)
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="font_color", before_value=f"#{before}" if before else "",
            after_value=action.font_color, timestamp=now,
        ))

    # Apply underline
    if action.underline is not None and rpr is not None:
        u = rpr.find(f"{{{w}}}u")
        before = None
        if u is not None:
            before = u.get(f"{{{w}}}val")
        else:
            u = etree.SubElement(rpr, f"{{{w}}}u")
        u.set(f"{{{w}}}val", action.underline)
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="underline", before_value=before,
            after_value=action.underline, timestamp=now,
        ))

    # Apply alignment
    if action.alignment and ppr is not None:
        jc = ppr.find(f"{{{w}}}jc")
        before = None
        if jc is not None:
            before = jc.get(f"{{{w}}}val")
        else:
            jc = etree.SubElement(ppr, f"{{{w}}}jc")
        align_map = {
            "left": "left", "center": "center", "right": "right",
            "justify": "both", "distribute": "distribute",
        }
        jc.set(f"{{{w}}}val", align_map.get(action.alignment, action.alignment))
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="alignment", before_value=before,
            after_value=action.alignment, timestamp=now,
        ))

    # Apply spacing
    if (action.space_before is not None or action.space_after is not None or
            action.line_spacing is not None) and ppr is not None:
        spacing = ppr.find(f"{{{w}}}spacing")
        if spacing is None:
            spacing = etree.SubElement(ppr, f"{{{w}}}spacing")

        if action.space_before is not None:
            before = spacing.get(f"{{{w}}}before", "0")
            spacing.set(f"{{{w}}}before", str(int(action.space_before * 20)))
            modifications.append(Modification(
                node_path=node.xml_xpath, rule_id=rule.id,
                property_name="space_before", before_value=float(before) / 20,
                after_value=action.space_before, timestamp=now,
            ))

        if action.space_after is not None:
            before = spacing.get(f"{{{w}}}after", "0")
            spacing.set(f"{{{w}}}after", str(int(action.space_after * 20)))
            modifications.append(Modification(
                node_path=node.xml_xpath, rule_id=rule.id,
                property_name="space_after", before_value=float(before) / 20,
                after_value=action.space_after, timestamp=now,
            ))

        if action.line_spacing is not None:
            before = spacing.get(f"{{{w}}}line", "240")
            spacing.set(f"{{{w}}}line", str(int(action.line_spacing * 240)))
            spacing.set(f"{{{w}}}lineRule", "auto")
            modifications.append(Modification(
                node_path=node.xml_xpath, rule_id=rule.id,
                property_name="line_spacing", before_value=float(before) / 240,
                after_value=action.line_spacing, timestamp=now,
            ))

    # Apply first line indent
    if action.first_line_indent is not None and ppr is not None:
        ind = ppr.find(f"{{{w}}}ind")
        if ind is None:
            ind = etree.SubElement(ppr, f"{{{w}}}ind")
        before = ind.get(f"{{{w}}}firstLine", "0")
        ind.set(f"{{{w}}}firstLine", str(int(action.first_line_indent * 20)))
        modifications.append(Modification(
            node_path=node.xml_xpath, rule_id=rule.id,
            property_name="first_line_indent", before_value=float(before) / 20,
            after_value=action.first_line_indent, timestamp=now,
        ))

    return modifications


def _needs_ppr(action: RuleAction) -> bool:
    return any([
        action.alignment, action.line_spacing,
        action.space_before, action.space_after,
        action.first_line_indent,
    ])


def _needs_rpr(action: RuleAction) -> bool:
    return any([
        action.font_cn, action.font_en, action.font_size,
        action.font_color, action.bold is not None,
        action.italic is not None, action.underline,
    ])
