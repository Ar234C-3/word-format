"""Template service."""

from typing import List, Optional
from sqlalchemy.orm import Session

from backend.models.template import Template
from backend.schemas.template import TemplateCreate, TemplateUpdate


def create_template(data: TemplateCreate, db: Session) -> Template:
    template = Template(
        name=data.name,
        description=data.description,
        format_rules=[r.model_dump() for r in data.format_rules],
        numbering_config=data.numbering_config,
        table_config=data.table_config,
    )
    db.add(template)
    db.commit()
    db.refresh(template)
    return template


def get_template(template_id: str, db: Session) -> Optional[Template]:
    return db.query(Template).filter(Template.id == template_id).first()


def list_templates(db: Session) -> List[Template]:
    return db.query(Template).order_by(Template.created_at.desc()).all()


def update_template(template_id: str, data: TemplateUpdate, db: Session) -> Optional[Template]:
    template = db.query(Template).filter(Template.id == template_id).first()
    if template is None:
        return None

    if data.name is not None:
        template.name = data.name
    if data.description is not None:
        template.description = data.description
    if data.format_rules is not None:
        template.format_rules = [r.model_dump() for r in data.format_rules]
    if data.numbering_config is not None:
        template.numbering_config = data.numbering_config
    if data.table_config is not None:
        template.table_config = data.table_config

    db.commit()
    db.refresh(template)
    return template


def delete_template(template_id: str, db: Session) -> bool:
    template = db.query(Template).filter(Template.id == template_id).first()
    if template is None:
        return False
    db.delete(template)
    db.commit()
    return True
