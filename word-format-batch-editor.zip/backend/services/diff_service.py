"""Diff service - generates before/after comparison reports."""

import difflib
from typing import List, Dict, Any
from backend.schemas.task import DiffReport, Modification


def generate_diff_report(
    document_id: str,
    document_name: str,
    original_path: str,
    modified_path: str,
    modifications: List[Modification],
) -> DiffReport:
    """Generate a diff report comparing original and modified documents."""
    changes = []

    for mod in modifications:
        change = {
            "node_path": mod.node_path,
            "rule_id": mod.rule_id,
            "property": mod.property_name,
            "before": mod.before_value,
            "after": mod.after_value,
            "timestamp": mod.timestamp.isoformat() if mod.timestamp else None,
        }
        changes.append(change)

    return DiffReport(
        document_id=document_id,
        document_name=document_name,
        original_path=original_path,
        modified_path=modified_path,
        changes=changes,
    )


def generate_text_diff(original_text: str, modified_text: str) -> List[str]:
    """Generate a unified diff between two text contents."""
    original_lines = original_text.splitlines(keepends=True)
    modified_lines = modified_text.splitlines(keepends=True)

    return list(difflib.unified_diff(
        original_lines, modified_lines,
        fromfile="original", tofile="modified",
        lineterm="",
    ))
