"""Numbering engine - handles numbering style modifications."""

from typing import Optional
from lxml import etree

from backend.core.ooxml_reader import OOXMLReader
from backend.core.ooxml_writer import NSMAP, pt_to_half_pt, pt_to_twips
from backend.core.numbering_parser import (
    parse_numbering, NumberingConfig, NumLevel, AbstractNum, NumMapping
)
from backend.schemas.format_spec import NumberingSpec


def modify_numbering(
    file_path: str,
    num_id: int,
    ilvl: int,
    spec: NumberingSpec,
    numbering_xml: Optional[etree._Element] = None,
) -> etree._Element:
    """Modify numbering styles in a document's numbering.xml.
    Returns the modified numbering.xml element."""
    w = NSMAP["w"]

    if numbering_xml is None:
        with OOXMLReader(file_path) as reader:
            numbering_xml = reader.get_numbering_xml()
            if numbering_xml is None:
                # Create a basic numbering.xml
                numbering_xml = etree.Element(f"{{{w}}}numbering")

    config = parse_numbering(numbering_xml)

    # Find or create the abstractNum for this numId
    mapping = config.num_mappings.get(num_id)
    if mapping is None:
        # Create new abstract num and mapping
        abs_id = max(config.abstract_nums.keys(), default=-1) + 1
        abstract = AbstractNum(abstract_num_id=abs_id)
        config.abstract_nums[abs_id] = abstract

        # Add abstractNum element
        abs_el = etree.SubElement(numbering_xml, f"{{{w}}}abstractNum")
        abs_el.set(f"{{{w}}}abstractNumId", str(abs_id))

        # Add num element
        num_el = etree.SubElement(numbering_xml, f"{{{w}}}num")
        num_el.set(f"{{{w}}}numId", str(num_id))
        abs_ref = etree.SubElement(num_el, f"{{{w}}}abstractNumId")
        abs_ref.set(f"{{{w}}}val", str(abs_id))

        mapping = NumMapping(num_id=num_id, abstract_num_id=abs_id)
        config.num_mappings[num_id] = mapping
    else:
        # Find existing abstractNum element
        abs_el = None
        for el in numbering_xml.findall(f"{{{w}}}abstractNum"):
            if el.get(f"{{{w}}}abstractNumId") == str(mapping.abstract_num_id):
                abs_el = el
                break
        if abs_el is None:
            abs_el = etree.SubElement(numbering_xml, f"{{{w}}}abstractNum")
            abs_el.set(f"{{{w}}}abstractNumId", str(mapping.abstract_num_id))

    # Find or create lvl element
    lvl_el = None
    for el in abs_el.findall(f"{{{w}}}lvl"):
        if el.get(f"{{{w}}}ilvl") == str(ilvl):
            lvl_el = el
            break

    if lvl_el is None:
        lvl_el = etree.SubElement(abs_el, f"{{{w}}}lvl")
        lvl_el.set(f"{{{w}}}ilvl", str(ilvl))

    # Apply format type
    num_fmt = lvl_el.find(f"{{{w}}}numFmt")
    if num_fmt is None:
        num_fmt = etree.SubElement(lvl_el, f"{{{w}}}numFmt")
    num_fmt.set(f"{{{w}}}val", spec.format_type)

    # Apply level text
    lvl_text = lvl_el.find(f"{{{w}}}lvlText")
    if lvl_text is None:
        lvl_text = etree.SubElement(lvl_el, f"{{{w}}}lvlText")
    lvl_text.set(f"{{{w}}}val", spec.prefix + "%1" + spec.suffix)

    # Apply start value
    start_el = lvl_el.find(f"{{{w}}}start")
    if start_el is None:
        start_el = etree.SubElement(lvl_el, f"{{{w}}}start")
    start_el.set(f"{{{w}}}val", str(spec.start_value))

    # Apply font properties
    if spec.indent_left_pt is not None or spec.hanging_pt is not None:
        ppr = lvl_el.find(f"{{{w}}}pPr")
        if ppr is None:
            ppr = etree.SubElement(lvl_el, f"{{{w}}}pPr")
        ind = ppr.find(f"{{{w}}}ind")
        if ind is None:
            ind = etree.SubElement(ppr, f"{{{w}}}ind")
        if spec.indent_left_pt is not None:
            ind.set(f"{{{w}}}left", str(pt_to_twips(spec.indent_left_pt)))
        if spec.hanging_pt is not None:
            ind.set(f"{{{w}}}hanging", str(pt_to_twips(spec.hanging_pt)))

    return numbering_xml


def format_numbering_text(pattern: str, counters: dict) -> str:
    """Format a numbering pattern with counter values.
    Supports {1}, {2}, ..., {upper_1}, {lower_1}, etc."""
    result = pattern
    for key, value in counters.items():
        result = result.replace(f"{{{key}}}", str(value))

    # Handle upper/lower variants
    for key, value in counters.items():
        result = result.replace(f"{{upper_{key}}}", _to_upper_alpha(value))
        result = result.replace(f"{{lower_{key}}}", _to_lower_alpha(value))
        result = result.replace(f"{{upper_roman_{key}}}", _to_upper_roman(value))
        result = result.replace(f"{{lower_roman_{key}}}", _to_lower_roman(value))

    return result


def _to_upper_alpha(n: int) -> str:
    """Convert number to uppercase letter (1=A, 2=B, ..., 26=Z)."""
    if 1 <= n <= 26:
        return chr(64 + n)
    return str(n)


def _to_lower_alpha(n: int) -> str:
    """Convert number to lowercase letter."""
    if 1 <= n <= 26:
        return chr(96 + n)
    return str(n)


def _to_upper_roman(n: int) -> str:
    """Convert number to uppercase Roman numeral."""
    vals = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"),
            (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
            (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    result = ""
    for val, numeral in vals:
        while n >= val:
            result += numeral
            n -= val
    return result


def _to_lower_roman(n: int) -> str:
    """Convert number to lowercase Roman numeral."""
    return _to_upper_roman(n).lower()
