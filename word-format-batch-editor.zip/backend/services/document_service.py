"""Document service - manages document CRUD and file operations."""

import os
import shutil
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from sqlalchemy.orm import Session

from backend.config import get_config
from backend.models.document import Document
from backend.schemas.document import DocumentResponse, DocumentListResponse
from backend.utils.file_utils import compute_sha256, validate_docx_magic
from backend.utils.zip_validator import validate_docx_zip


def save_uploaded_file(
    file_content: bytes,
    filename: str,
    db: Session,
    tags: List[str] = None,
) -> Document:
    """Save an uploaded file and create a document record."""
    config = get_config()
    storage = Path(config.storage.base_path)

    # Generate unique ID and paths
    doc_id = str(uuid.uuid4())
    safe_name = _sanitize_filename(filename)
    original_dir = storage / "original" / doc_id
    original_dir.mkdir(parents=True, exist_ok=True)
    original_path = original_dir / safe_name

    # Write file
    with open(original_path, "wb") as f:
        f.write(file_content)

    # Validate
    if not validate_docx_magic(str(original_path)):
        os.remove(original_path)
        raise ValueError("Not a valid .docx file (invalid magic bytes)")

    valid, msg = validate_docx_zip(str(original_path))
    if not valid:
        os.remove(original_path)
        raise ValueError(f"Invalid .docx file: {msg}")

    # Compute hash
    sha256 = compute_sha256(str(original_path))

    # Create snapshot
    snapshot_dir = storage / "snapshots" / doc_id
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(original_path), str(snapshot_dir / safe_name))

    # Create database record
    doc = Document(
        id=doc_id,
        name=safe_name,
        original_path=str(original_path),
        snapshot_path=str(snapshot_dir / safe_name),
        size=len(file_content),
        sha256=sha256,
        tags=tags or [],
        status="UPLOADED",
    )
    db.add(doc)
    db.commit()
    db.refresh(doc)

    return doc


def get_document(doc_id: str, db: Session) -> Optional[Document]:
    return db.query(Document).filter(Document.id == doc_id).first()


def list_documents(
    db: Session, page: int = 1, size: int = 20,
    sort: str = "created_at", status: Optional[str] = None,
    tag: Optional[str] = None,
) -> Tuple[List[Document], int]:
    """List documents with filtering and pagination."""
    query = db.query(Document)

    if status:
        query = query.filter(Document.status == status)
    if tag:
        query = query.filter(Document.tags.contains([tag]))

    total = query.count()

    # Sort
    if sort == "name":
        query = query.order_by(Document.name)
    elif sort == "size":
        query = query.order_by(Document.size.desc())
    else:
        query = query.order_by(Document.created_at.desc())

    docs = query.offset((page - 1) * size).limit(size).all()
    return docs, total


def delete_document(doc_id: str, db: Session) -> bool:
    """Delete a document and its files."""
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if doc is None:
        return False

    # Delete files
    for path in [doc.original_path, doc.processed_path, doc.snapshot_path]:
        if path and os.path.exists(path):
            parent = os.path.dirname(path)
            if os.path.isdir(parent):
                shutil.rmtree(parent, ignore_errors=True)

    db.delete(doc)
    db.commit()
    return True


def _sanitize_filename(name: str) -> str:
    """Sanitize a filename."""
    # Remove path components
    name = os.path.basename(name)
    # Remove dangerous characters
    name = "".join(c for c in name if c.isalnum() or c in "._- ")
    if not name:
        name = "document.docx"
    if not name.endswith(".docx"):
        name += ".docx"
    return name
