"""Celery process task - handles batch document processing."""

import os
import uuid
import shutil
from datetime import datetime
from pathlib import Path

from backend.config import get_config
from backend.database import init_db, get_session_factory
from backend.models.document import Document
from backend.models.task import Task
from backend.models.log_entry import LogEntry
from backend.schemas.format_spec import FormatRule
from backend.services.format_engine import apply_format_rules
from backend.services.structure_parser import parse_document_structure
from backend.utils.logger import setup_logger

logger = setup_logger()


def create_celery_app():
    """Create and configure Celery application."""
    from celery import Celery

    config = get_config()
    app = Celery(
        "word_format_editor",
        broker=config.celery.broker_url,
        backend=config.celery.result_backend,
    )
    app.conf.update(
        task_serializer="json",
        accept_content=["json"],
        result_serializer="json",
        timezone="UTC",
        enable_utc=True,
        worker_concurrency=config.celery.concurrency,
        worker_pool="solo",
    )
    return app


celery_app = create_celery_app()


@celery_app.task(bind=True, name="process_document")
def process_document_task(self, task_id: str, document_id: str, rules_data: list):
    """Process a single document with the given rules."""
    engine = init_db()
    Session = get_session_factory(engine)
    db = Session()

    try:
        # Update task status
        task = db.query(Task).filter(Task.id == task_id).first()
        if task and task.status == "PENDING":
            task.status = "RUNNING"
            task.started_at = datetime.utcnow()
            db.commit()

        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc is None:
            logger.error(f"Document {document_id} not found")
            return {"status": "ERROR", "error": "Document not found"}

        doc.status = "PROCESSING"
        db.commit()

        config = get_config()
        storage = Path(config.storage.base_path)

        # Parse rules
        rules = [FormatRule(**r) for r in rules_data]

        # Prepare output path
        output_dir = storage / "processed" / document_id
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = str(output_dir / doc.name)

        # Create snapshot
        snapshot_path = doc.snapshot_path
        if not snapshot_path:
            snapshot_dir = storage / "snapshots" / document_id
            snapshot_dir.mkdir(parents=True, exist_ok=True)
            snapshot_path = str(snapshot_dir / doc.name)
            shutil.copy2(doc.original_path, snapshot_path)
            doc.snapshot_path = snapshot_path

        # Apply format rules
        result_path, modifications = apply_format_rules(
            file_path=doc.original_path,
            output_path=output_path,
            rules=rules,
            document_id=document_id,
        )

        # Update document record
        doc.processed_path = result_path
        doc.status = "DONE"
        db.commit()

        # Log modifications
        for mod in modifications:
            log = LogEntry(
                level="INFO",
                action="format_change",
                document_id=document_id,
                task_id=task_id,
                node_path=mod.node_path,
                rule_id=mod.rule_id,
                message=f"Changed {mod.property_name}",
                before_value=mod.before_value,
                after_value=mod.after_value,
            )
            db.add(log)
        db.commit()

        logger.info(f"Document {doc.name} processed: {len(modifications)} modifications")

        # Update task progress
        task = db.query(Task).filter(Task.id == task_id).first()
        if task:
            task.processed_documents += 1
            task.success_count += 1
            if task.total_documents > 0:
                task.progress = task.processed_documents / task.total_documents
            db.commit()

        return {
            "status": "SUCCESS",
            "document_id": document_id,
            "modifications_count": len(modifications),
        }

    except Exception as e:
        logger.exception(f"Error processing document {document_id}")

        # Mark document as error
        doc = db.query(Document).filter(Document.id == document_id).first()
        if doc:
            doc.status = "ERROR"
            doc.error_message = str(e)
            db.commit()

        # Update task
        task = db.query(Task).filter(Task.id == task_id).first()
        if task:
            task.processed_documents += 1
            task.error_count += 1
            if task.total_documents > 0:
                task.progress = task.processed_documents / task.total_documents
            db.commit()

        return {"status": "ERROR", "document_id": document_id, "error": str(e)}

    finally:
        db.close()


@celery_app.task(name="process_batch")
def process_batch_task(task_id: str, document_ids: list, rules_data: list):
    """Process a batch of documents sequentially."""
    engine = init_db()
    Session = get_session_factory(engine)
    db = Session()

    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if task:
            task.status = "RUNNING"
            task.started_at = datetime.utcnow()
            db.commit()

        results = []
        for doc_id in document_ids:
            # Check if task was cancelled or paused
            db.refresh(task)
            if task.status == "CANCELLED":
                break
            while task.status == "PAUSED":
                import time
                time.sleep(1)
                db.refresh(task)
                if task.status == "CANCELLED":
                    break

            result = process_document_task.delay(task_id, doc_id, rules_data)
            results.append(result.get())  # Wait for each to complete

        # Mark task as done
        task = db.query(Task).filter(Task.id == task_id).first()
        if task and task.status != "CANCELLED":
            task.status = "DONE"
            task.completed_at = datetime.utcnow()
            db.commit()

    finally:
        db.close()
