"""Celery Worker entry point."""

from backend.tasks.process_task import celery_app

if __name__ == "__main__":
    celery_app.worker_main(["worker", "--pool=solo", "--loglevel=info"])
