"""Unified response wrapper."""

from typing import Any, Optional
from pydantic import BaseModel


class UnifiedResponse(BaseModel):
    code: int = 0
    message: str = "success"
    data: Optional[Any] = None

    @classmethod
    def success(cls, data: Any = None, message: str = "success") -> "UnifiedResponse":
        return cls(code=0, message=message, data=data)

    @classmethod
    def error(cls, code: int, message: str) -> "UnifiedResponse":
        return cls(code=code, message=message, data=None)
