"""Template schemas."""

from typing import Optional, List
from pydantic import BaseModel
from backend.schemas.format_spec import FormatRule


class TemplateCreate(BaseModel):
    name: str
    description: Optional[str] = None
    format_rules: List[FormatRule] = []
    numbering_config: Optional[dict] = None
    table_config: Optional[dict] = None


class TemplateUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    format_rules: Optional[List[FormatRule]] = None
    numbering_config: Optional[dict] = None
    table_config: Optional[dict] = None


class TemplateResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    format_rules: List[dict]
    numbering_config: Optional[dict]
    table_config: Optional[dict]
    is_default: bool

    class Config:
        from_attributes = True
