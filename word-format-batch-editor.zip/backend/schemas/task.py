"""Task schemas."""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from backend.schemas.format_spec import FormatRule


class TaskCreate(BaseModel):
    document_ids: List[str]
    rules: List[FormatRule] = []
    template_id: Optional[str] = None
    name: Optional[str] = None


class TaskStatus(BaseModel):
    id: str
    name: Optional[str]
    status: str
    total_documents: int
    processed_documents: int
    success_count: int
    error_count: int
    skipped_count: int
    progress: float
    estimated_seconds: Optional[int]
    error_message: Optional[str]
    created_at: Optional[datetime]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]

    class Config:
        from_attributes = True


class Modification(BaseModel):
    node_path: str
    rule_id: Optional[str]
    property_name: str
    before_value: Any
    after_value: Any
    timestamp: datetime


class ProcessResult(BaseModel):
    document_id: str
    document_name: str
    status: str  # SUCCESS/ERROR/SKIPPED
    modifications: List[Modification] = []
    error_message: Optional[str] = None
    output_path: Optional[str] = None


class DryRunReport(BaseModel):
    total_documents: int
    would_modify: int
    would_skip: int
    would_error: int
    estimated_seconds: int
    results: List[ProcessResult]


class DiffReport(BaseModel):
    document_id: str
    document_name: str
    original_path: str
    modified_path: str
    changes: List[Dict[str, Any]]
