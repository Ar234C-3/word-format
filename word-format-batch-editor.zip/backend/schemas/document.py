"""Document schemas."""

from typing import Optional, List, Dict, Literal
from pydantic import BaseModel
from backend.schemas.format_spec import FormatSpec


class MergedCell(BaseModel):
    row: int
    col: int
    row_span: int = 1
    col_span: int = 1


class TableInfo(BaseModel):
    rows: int
    cols: int
    merged_cells: List[MergedCell] = []
    nested_tables: List[str] = []
    has_header_row: bool = False


class SectionInfo(BaseModel):
    id: str
    title: str
    level: int
    node_id: str
    children: List["SectionInfo"] = []


class DocumentNode(BaseModel):
    id: str
    type: Literal["heading", "paragraph", "table", "list_item", "image", "page_break", "section_break"]
    level: int = 0
    parent_id: Optional[str] = None
    children_ids: List[str] = []
    section_id: str
    content_preview: str
    style_name: str
    xml_xpath: str
    current_format: FormatSpec
    table_info: Optional[TableInfo] = None


class StructureStats(BaseModel):
    heading_count: int = 0
    paragraph_count: int = 0
    table_count: int = 0
    list_count: int = 0
    image_count: int = 0
    total_nodes: int = 0


class DocumentStructure(BaseModel):
    document_id: str
    total_pages: int
    sections: List[SectionInfo]
    nodes: Dict[str, DocumentNode]
    root_node_ids: List[str]
    statistics: StructureStats


class DocumentCreate(BaseModel):
    name: str
    tags: List[str] = []


class DocumentResponse(BaseModel):
    id: str
    name: str
    size: int
    pages: int
    status: str
    tags: List[str] = []
    created_at: Optional[str] = None

    class Config:
        from_attributes = True


class DocumentListResponse(BaseModel):
    items: List[DocumentResponse]
    total: int
    page: int
    size: int
