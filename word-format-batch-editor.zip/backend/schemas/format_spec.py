"""Format specification schemas."""

from typing import Optional, Literal
from pydantic import BaseModel, Field


class NumberingSpec(BaseModel):
    """Numbering style specification."""
    format_type: str = "decimal"  # decimal/upperRoman/lowerRoman/upperLetter/lowerLetter/none
    prefix: str = ""
    suffix: str = "."  # separator after number
    start_value: int = 1
    level_format: Optional[str] = None  # e.g. "{1}.{2}.{3}"
    indent_left_pt: Optional[float] = None
    hanging_pt: Optional[float] = None


class TableFormatSpec(BaseModel):
    """Table format specification."""
    border_style: Optional[str] = None  # single/double/none
    border_color: Optional[str] = None
    border_width_pt: Optional[float] = None
    header_bg_color: Optional[str] = None
    header_font_bold: Optional[bool] = None
    cell_padding_pt: Optional[float] = None
    cell_vertical_align: Optional[str] = None  # top/center/bottom
    row_height_pt: Optional[float] = None
    autofit: Optional[bool] = None


class FormatSpec(BaseModel):
    """Direct format specification - captures all formatting properties."""
    font_cn: Optional[str] = None
    font_en: Optional[str] = None
    font_size: Optional[float] = None  # pt
    font_color: Optional[str] = None  # HEX "#RRGGBB"
    bold: Optional[bool] = None
    italic: Optional[bool] = None
    underline: Optional[Literal["single", "double", "wave"]] = None
    alignment: Optional[Literal["left", "center", "right", "justify", "distribute"]] = None
    line_spacing: Optional[float] = None  # multiple or fixed pt
    space_before: Optional[float] = None  # pt
    space_after: Optional[float] = None  # pt
    first_line_indent: Optional[float] = None  # pt
    numbering: Optional[NumberingSpec] = None
    table_format: Optional[TableFormatSpec] = None


class RuleCondition(BaseModel):
    """Condition for matching document nodes."""
    node_type: Optional[Literal["heading", "paragraph", "table", "list_item"]] = None
    level: Optional[int] = None
    style_name_contains: Optional[str] = None
    content_contains: Optional[str] = None
    section_title_contains: Optional[str] = None
    table_min_rows: Optional[int] = None
    table_max_rows: Optional[int] = None
    custom_expression: Optional[str] = None


class RuleAction(BaseModel):
    """Action to apply when a rule matches."""
    font_cn: Optional[str] = None
    font_en: Optional[str] = None
    font_size: Optional[float] = None
    font_color: Optional[str] = None
    bold: Optional[bool] = None
    italic: Optional[bool] = None
    underline: Optional[Literal["single", "double", "wave"]] = None
    alignment: Optional[Literal["left", "center", "right", "justify", "distribute"]] = None
    line_spacing: Optional[float] = None
    space_before: Optional[float] = None
    space_after: Optional[float] = None
    first_line_indent: Optional[float] = None
    numbering: Optional[NumberingSpec] = None
    table_format: Optional[TableFormatSpec] = None


class FormatRule(BaseModel):
    """A named format rule with condition and action."""
    id: str
    name: str
    priority: int = 0
    enabled: bool = True
    condition: RuleCondition
    action: RuleAction
