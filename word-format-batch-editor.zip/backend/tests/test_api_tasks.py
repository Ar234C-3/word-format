"""Tests for tasks API."""

import pytest
from fastapi.testclient import TestClient


class TestTasksAPI:
    """Test task API endpoints."""

    @pytest.fixture
    def client(self):
        from backend.main import app
        return TestClient(app)

    def test_list_tasks(self, client):
        response = client.get("/api/v1/tasks")
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert "items" in data["data"]

    def test_dry_run_no_documents(self, client):
        response = client.post("/api/v1/tasks/dry-run", json={
            "document_ids": [],
            "rules": [],
        })
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert data["data"]["total_documents"] == 0

    def test_create_task_empty(self, client):
        response = client.post("/api/v1/tasks", json={
            "document_ids": [],
            "rules": [],
        })
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0

    def test_task_not_found(self, client):
        response = client.get("/api/v1/tasks/nonexistent")
        assert response.status_code == 200
        data = response.json()
        assert data["code"] != 0
