"""Pytest configuration and fixtures."""

import os
import sys
import pytest
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from backend.database import Base, get_engine, get_session_factory


@pytest.fixture
def db_session():
    """Create a test database session."""
    engine = get_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)
    Session = get_session_factory(engine)
    session = Session()
    yield session
    session.close()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def fixtures_dir():
    """Path to test fixtures directory."""
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def sample_docx(fixtures_dir):
    """Path to a sample .docx file for testing."""
    path = fixtures_dir / "simple.docx"
    if not path.exists():
        create_simple_docx(path)
    return str(path)


@pytest.fixture
def headings_docx(fixtures_dir):
    """Path to a headings test .docx file."""
    path = fixtures_dir / "headings_multi.docx"
    if not path.exists():
        create_headings_docx(path)
    return str(path)


@pytest.fixture
def tables_docx(fixtures_dir):
    """Path to a tables test .docx file."""
    path = fixtures_dir / "tables_complex.docx"
    if not path.exists():
        create_tables_docx(path)
    return str(path)


@pytest.fixture
def lists_docx(fixtures_dir):
    """Path to a lists test .docx file."""
    path = fixtures_dir / "lists_mixed.docx"
    if not path.exists():
        create_lists_docx(path)
    return str(path)


def create_simple_docx(path):
    """Create a simple test .docx with 10 paragraphs."""
    from docx import Document
    doc = Document()
    for i in range(1, 11):
        doc.add_paragraph(f"This is paragraph {i} with some sample text for testing purposes.")
    doc.save(str(path))


def create_headings_docx(path):
    """Create a test .docx with Heading1-9."""
    from docx import Document
    doc = Document()
    doc.add_heading("Document Title", level=0)
    for level in range(1, 10):
        doc.add_heading(f"Heading Level {level}", level=level)
        doc.add_paragraph(f"Content under heading level {level}.")
    doc.save(str(path))


def create_tables_docx(path):
    """Create a test .docx with complex tables."""
    from docx import Document
    from docx.shared import Inches
    doc = Document()

    # Simple table
    table = doc.add_table(rows=3, cols=3)
    table.style = "Table Grid"
    for i, row in enumerate(table.rows):
        for j, cell in enumerate(row.cells):
            cell.text = f"Cell {i},{j}"

    doc.add_paragraph("")

    # Larger table
    table2 = doc.add_table(rows=5, cols=4)
    table2.style = "Table Grid"
    for i, row in enumerate(table2.rows):
        for j, cell in enumerate(row.cells):
            cell.text = f"R{i}C{j}"

    doc.save(str(path))


def create_lists_docx(path):
    """Create a test .docx with mixed lists."""
    from docx import Document
    doc = Document()

    doc.add_heading("Lists Test", level=1)

    # Unordered list
    doc.add_paragraph("Item 1", style="List Bullet")
    doc.add_paragraph("Item 2", style="List Bullet")
    doc.add_paragraph("Sub-item 2.1", style="List Bullet 2")
    doc.add_paragraph("Sub-item 2.2", style="List Bullet 2")

    # Ordered list
    doc.add_paragraph("First", style="List Number")
    doc.add_paragraph("Second", style="List Number")
    doc.add_paragraph("Third", style="List Number")

    doc.save(str(path))
