"""Tests for numbering_engine module."""

import pytest
from backend.schemas.format_spec import NumberingSpec
from backend.services.numbering_engine import (
    format_numbering_text,
    _to_upper_alpha, _to_lower_alpha,
    _to_upper_roman, _to_lower_roman,
)


class TestNumberingEngine:
    """Test numbering engine utilities."""

    def test_format_numbering_text_basic(self):
        result = format_numbering_text("%1.", {1: 5})
        # The engine uses {1} not %1 - let's test the correct pattern
        result = format_numbering_text("{1}.", {1: 5})
        assert result == "5."

    def test_format_numbering_text_multi_level(self):
        result = format_numbering_text("{1}.{2}.", {1: 3, 2: 7})
        assert result == "3.7."

    def test_to_upper_alpha(self):
        assert _to_upper_alpha(1) == "A"
        assert _to_upper_alpha(26) == "Z"
        assert _to_upper_alpha(27) == "27"

    def test_to_lower_alpha(self):
        assert _to_lower_alpha(1) == "a"
        assert _to_lower_alpha(26) == "z"

    def test_to_upper_roman(self):
        assert _to_upper_roman(1) == "I"
        assert _to_upper_roman(4) == "IV"
        assert _to_upper_roman(9) == "IX"
        assert _to_upper_roman(10) == "X"
        assert _to_upper_roman(42) == "XLII"

    def test_to_lower_roman(self):
        assert _to_lower_roman(1) == "i"
        assert _to_lower_roman(4) == "iv"

    def test_numbering_spec_defaults(self):
        spec = NumberingSpec()
        assert spec.format_type == "decimal"
        assert spec.prefix == ""
        assert spec.suffix == "."
        assert spec.start_value == 1
