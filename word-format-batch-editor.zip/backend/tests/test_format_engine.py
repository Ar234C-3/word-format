"""Tests for format_engine module."""

import os
import pytest
import tempfile
from backend.services.format_engine import apply_format_rules
from backend.schemas.format_spec import FormatRule, RuleCondition, RuleAction


class TestFormatEngine:
    """Test format application engine."""

    def test_apply_font_size(self, sample_docx):
        rules = [FormatRule(
            id="r1", name="Set font size", priority=1,
            condition=RuleCondition(node_type="paragraph"),
            action=RuleAction(font_size=14.0),
        )]
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(sample_docx, output, rules, "test-doc")
            assert os.path.exists(path)
            assert len(mods) > 0
        finally:
            if os.path.exists(output):
                os.remove(output)

    def test_apply_bold(self, sample_docx):
        rules = [FormatRule(
            id="r2", name="Bold all", priority=1,
            condition=RuleCondition(),
            action=RuleAction(bold=True),
        )]
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(sample_docx, output, rules, "test-doc")
            bold_mods = [m for m in mods if m.property_name == "bold"]
            assert len(bold_mods) > 0
        finally:
            if os.path.exists(output):
                os.remove(output)

    def test_apply_alignment(self, sample_docx):
        rules = [FormatRule(
            id="r3", name="Center all", priority=1,
            condition=RuleCondition(),
            action=RuleAction(alignment="center"),
        )]
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(sample_docx, output, rules, "test-doc")
            align_mods = [m for m in mods if m.property_name == "alignment"]
            assert len(align_mods) > 0
        finally:
            if os.path.exists(output):
                os.remove(output)

    def test_heading_only_rule(self, headings_docx):
        rules = [FormatRule(
            id="r4", name="Heading font", priority=1,
            condition=RuleCondition(node_type="heading", level=1),
            action=RuleAction(font_size=22.0, bold=True),
        )]
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(headings_docx, output, rules, "test-headings")
            # Should only affect heading level 1
            assert len(mods) > 0
        finally:
            if os.path.exists(output):
                os.remove(output)

    def test_modifications_recorded(self, sample_docx):
        rules = [FormatRule(
            id="r5", name="Color red", priority=1,
            condition=RuleCondition(node_type="paragraph"),
            action=RuleAction(font_color="#FF0000"),
        )]
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(sample_docx, output, rules, "test-doc")
            for mod in mods:
                assert mod.node_path is not None
                assert mod.rule_id == "r5"
                assert mod.timestamp is not None
        finally:
            if os.path.exists(output):
                os.remove(output)

    def test_empty_rules(self, sample_docx):
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as f:
            output = f.name

        try:
            path, mods = apply_format_rules(sample_docx, output, [], "test-doc")
            assert len(mods) == 0
            assert os.path.exists(path)
        finally:
            if os.path.exists(output):
                os.remove(output)
