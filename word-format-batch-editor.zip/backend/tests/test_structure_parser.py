"""Tests for structure_parser module."""

import pytest
from backend.services.structure_parser import parse_document_structure


class TestStructureParser:
    """Test document structure parsing."""

    def test_parse_simple_document(self, sample_docx):
        structure = parse_document_structure(sample_docx, "test-doc-1")
        assert structure.document_id == "test-doc-1"
        assert structure.total_pages >= 1
        assert structure.statistics.paragraph_count >= 10
        assert len(structure.nodes) > 0

    def test_parse_headings(self, headings_docx):
        structure = parse_document_structure(headings_docx, "test-headings")
        headings = [n for n in structure.nodes.values() if n.type == "heading"]
        assert len(headings) >= 9
        # Check heading levels
        levels = sorted(set(h.level for h in headings))
        assert 1 in levels

    def test_parse_tables(self, tables_docx):
        structure = parse_document_structure(tables_docx, "test-tables")
        tables = [n for n in structure.nodes.values() if n.type == "table"]
        assert len(tables) >= 2
        # Check table dimensions
        first_table = tables[0]
        assert first_table.table_info is not None
        assert first_table.table_info.rows >= 3
        assert first_table.table_info.cols >= 3

    def test_parse_lists(self, lists_docx):
        structure = parse_document_structure(lists_docx, "test-lists")
        list_items = [n for n in structure.nodes.values() if n.type == "list_item"]
        assert len(list_items) >= 7

    def test_root_node_ids(self, sample_docx):
        structure = parse_document_structure(sample_docx, "test-roots")
        assert len(structure.root_node_ids) > 0
        # All root nodes should exist in nodes dict
        for nid in structure.root_node_ids:
            assert nid in structure.nodes

    def test_content_preview_length(self, sample_docx):
        structure = parse_document_structure(sample_docx, "test-preview")
        for node in structure.nodes.values():
            assert len(node.content_preview) <= 50

    def test_section_assignment(self, headings_docx):
        structure = parse_document_structure(headings_docx, "test-sections")
        # Non-heading nodes should have a section_id
        for node in structure.nodes.values():
            if node.type != "heading":
                assert node.section_id is not None

    def test_statistics(self, sample_docx):
        structure = parse_document_structure(sample_docx, "test-stats")
        assert structure.statistics.total_nodes == len(structure.nodes)
        assert structure.statistics.paragraph_count > 0
