"""Tests for documents API."""

import pytest
from fastapi.testclient import TestClient


class TestDocumentsAPI:
    """Test document API endpoints."""

    @pytest.fixture
    def client(self):
        from backend.main import app
        return TestClient(app)

    def test_health_check(self, client):
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert "uptime" in data

    def test_upload_document(self, client, sample_docx):
        with open(sample_docx, "rb") as f:
            response = client.post(
                "/api/v1/documents/upload",
                files={"file": ("test.docx", f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert data["data"]["name"].endswith(".docx")
        assert data["data"]["status"] == "UPLOADED"

    def test_list_documents(self, client):
        response = client.get("/api/v1/documents")
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert "items" in data["data"]
        assert "total" in data["data"]

    def test_get_structure(self, client, sample_docx):
        # Upload first
        with open(sample_docx, "rb") as f:
            upload_res = client.post(
                "/api/v1/documents/upload",
                files={"file": ("test.docx", f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
        doc_id = upload_res.json()["data"]["id"]

        response = client.get(f"/api/v1/documents/{doc_id}/structure")
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert "nodes" in data["data"]

    def test_get_preview(self, client, sample_docx):
        with open(sample_docx, "rb") as f:
            upload_res = client.post(
                "/api/v1/documents/upload",
                files={"file": ("test.docx", f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
        doc_id = upload_res.json()["data"]["id"]

        response = client.get(f"/api/v1/documents/{doc_id}/preview")
        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert "html" in data["data"]

    def test_delete_document(self, client, sample_docx):
        with open(sample_docx, "rb") as f:
            upload_res = client.post(
                "/api/v1/documents/upload",
                files={"file": ("test.docx", f, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            )
        doc_id = upload_res.json()["data"]["id"]

        response = client.delete(f"/api/v1/documents/{doc_id}")
        assert response.status_code == 200
        assert response.json()["data"]["deleted"] is True

    def test_invalid_file_upload(self, client):
        import io
        response = client.post(
            "/api/v1/documents/upload",
            files={"file": ("test.txt", io.BytesIO(b"not a docx"), "text/plain")},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["code"] != 0  # Should return error
