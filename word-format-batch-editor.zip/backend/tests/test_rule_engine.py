"""Tests for rule_engine module."""

import pytest
from backend.schemas.format_spec import FormatRule, RuleCondition, RuleAction
from backend.schemas.document import DocumentNode, DocumentStructure, FormatSpec
from backend.services.rule_engine import match_rules, validate_rule, _evaluate_condition


class TestRuleEngine:
    """Test rule matching engine."""

    def _make_node(self, **kwargs):
        defaults = {
            "id": "n1", "type": "paragraph", "level": 0,
            "parent_id": None, "children_ids": [], "section_id": "s1",
            "content_preview": "Test paragraph", "style_name": "Normal",
            "xml_xpath": "/body/p", "current_format": FormatSpec(),
        }
        defaults.update(kwargs)
        return DocumentNode(**defaults)

    def _make_structure(self, nodes):
        from backend.schemas.document import StructureStats
        return DocumentStructure(
            document_id="test", total_pages=1,
            sections=[], nodes={n.id: n for n in nodes},
            root_node_ids=[n.id for n in nodes],
            statistics=StructureStats(total_nodes=len(nodes)),
        )

    def test_match_by_node_type(self):
        para = self._make_node(type="paragraph")
        heading = self._make_node(id="n2", type="heading", level=1)
        structure = self._make_structure([para, heading])

        rule = FormatRule(
            id="r1", name="Para rule", priority=1,
            condition=RuleCondition(node_type="paragraph"),
            action=RuleAction(bold=True),
        )

        result = match_rules(structure, [rule])
        assert "n1" in result
        assert "n2" not in result

    def test_match_by_level(self):
        h1 = self._make_node(id="h1", type="heading", level=1)
        h2 = self._make_node(id="h2", type="heading", level=2)
        structure = self._make_structure([h1, h2])

        rule = FormatRule(
            id="r2", name="H1 only", priority=1,
            condition=RuleCondition(node_type="heading", level=1),
            action=RuleAction(font_size=22.0),
        )

        result = match_rules(structure, [rule])
        assert "h1" in result
        assert "h2" not in result

    def test_match_by_content_contains(self):
        node = self._make_node(content_preview="重要通知：请查看")
        structure = self._make_structure([node])

        rule = FormatRule(
            id="r3", name="Important", priority=1,
            condition=RuleCondition(content_contains="重要"),
            action=RuleAction(bold=True, font_color="#FF0000"),
        )

        result = match_rules(structure, [rule])
        assert "n1" in result

    def test_priority_ordering(self):
        node = self._make_node()
        structure = self._make_structure([node])

        low_rule = FormatRule(
            id="low", name="Low", priority=1,
            condition=RuleCondition(),
            action=RuleAction(font_size=10.0),
        )
        high_rule = FormatRule(
            id="high", name="High", priority=10,
            condition=RuleCondition(),
            action=RuleAction(font_size=20.0),
        )

        result = match_rules(structure, [low_rule, high_rule])
        assert result["n1"][0].id == "high"

    def test_disabled_rule_ignored(self):
        node = self._make_node()
        structure = self._make_structure([node])

        rule = FormatRule(
            id="r4", name="Disabled", priority=1, enabled=False,
            condition=RuleCondition(),
            action=RuleAction(bold=True),
        )

        result = match_rules(structure, [rule])
        assert "n1" not in result

    def test_validate_rule_valid(self):
        rule = FormatRule(
            id="r1", name="Valid", priority=1,
            condition=RuleCondition(),
            action=RuleAction(font_size=12.0),
        )
        errors = validate_rule(rule)
        assert len(errors) == 0

    def test_validate_rule_missing_id(self):
        rule = FormatRule(
            id="", name="No ID", priority=1,
            condition=RuleCondition(),
            action=RuleAction(),
        )
        errors = validate_rule(rule)
        assert len(errors) > 0

    def test_safe_eval_blocks_imports(self):
        node = self._make_node()
        structure = self._make_structure([node])

        rule = FormatRule(
            id="r5", name="Evil", priority=1,
            condition=RuleCondition(custom_expression="__import__('os').system('rm -rf /')"),
            action=RuleAction(),
        )

        result = _evaluate_condition(rule.condition, node, structure)
        assert result is False

    def test_safe_eval_allows_simple_expressions(self):
        node = self._make_node(level=2)
        structure = self._make_structure([node])

        condition = RuleCondition(custom_expression="level > 1")
        result = _evaluate_condition(condition, node, structure)
        assert result is True

    def test_table_conditions(self):
        from backend.schemas.document import TableInfo
        table = self._make_node(
            id="t1", type="table",
            table_info=TableInfo(rows=5, cols=3),
        )
        structure = self._make_structure([table])

        rule = FormatRule(
            id="r6", name="Big table", priority=1,
            condition=RuleCondition(node_type="table", table_min_rows=3),
            action=RuleAction(),
        )

        result = match_rules(structure, [rule])
        assert "t1" in result
