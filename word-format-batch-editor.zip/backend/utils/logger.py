"""Loguru configuration."""

import sys
from pathlib import Path
from loguru import logger
from backend.config import get_config


def setup_logger():
    """Configure loguru with file and console handlers."""
    config = get_config().logging

    # Remove default handler
    logger.remove()

    # Console handler
    logger.add(
        sys.stderr,
        level=config.level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    )

    # File handler
    log_path = Path(config.file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    logger.add(
        str(log_path),
        level=config.level,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        rotation=f"{config.max_size_mb} MB",
        retention=config.backup_count,
        encoding="utf-8",
    )

    return logger
