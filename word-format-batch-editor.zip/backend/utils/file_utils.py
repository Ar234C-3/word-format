"""File utility functions."""

import hashlib
from pathlib import Path
from typing import Optional


def compute_sha256(file_path: str) -> str:
    """Compute SHA256 hash of a file."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def validate_docx_magic(file_path: str) -> bool:
    """Check if file starts with PK magic bytes (ZIP/DOCX)."""
    try:
        with open(file_path, "rb") as f:
            magic = f.read(4)
        return magic[:2] == b"PK"
    except Exception:
        return False


def safe_path_join(base: str, *parts: str) -> Optional[str]:
    """Join paths and ensure result is under base directory (prevent path traversal)."""
    base_path = Path(base).resolve()
    result = (base_path / Path(*parts)).resolve()
    if not str(result).startswith(str(base_path)):
        return None
    return str(result)


def get_file_size_mb(file_path: str) -> float:
    """Get file size in MB."""
    return Path(file_path).stat().st_size / (1024 * 1024)
