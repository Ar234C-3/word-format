"""ZIP validation for .docx files."""

import zipfile
from typing import Tuple


def validate_docx_zip(file_path: str) -> Tuple[bool, str]:
    """Validate that a .docx file is a valid ZIP with required entries."""
    try:
        with zipfile.ZipFile(file_path, "r") as zf:
            # Check for required OOXML entries
            names = zf.namelist()
            required = ["[Content_Types].xml", "word/document.xml"]
            for req in required:
                if req not in names:
                    return False, f"Missing required entry: {req}"

            # Test integrity
            bad = zf.testzip()
            if bad:
                return False, f"Corrupted entry: {bad}"

            return True, "OK"
    except zipfile.BadZipFile:
        return False, "Invalid ZIP file"
    except Exception as e:
        return False, str(e)
