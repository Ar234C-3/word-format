"""FastAPI dependencies - auth, db session."""

from datetime import datetime, timedelta
from typing import Optional

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from backend.config import get_config
from backend.database import get_db

security = HTTPBearer(auto_error=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    config = get_config()
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=config.security.jwt_expire_minutes))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, config.security.jwt_secret, algorithm="HS256")


def create_refresh_token(data: dict) -> str:
    config = get_config()
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(days=7)
    to_encode.update({"exp": expire, "type": "refresh"})
    return jwt.encode(to_encode, config.security.jwt_secret, algorithm="HS256")


def decode_token(token: str) -> dict:
    config = get_config()
    try:
        return jwt.decode(token, config.security.jwt_secret, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: Session = Depends(get_db),
):
    """Get current authenticated user. For simplicity, auto-create default admin if no users exist."""
    from backend.models.user import User

    # If no auth header, check if we should auto-login
    if credentials is None:
        # Auto-create default admin if no users
        user = db.query(User).first()
        if user is None:
            user = User(username="admin", password_hash=hash_password("admin"))
            db.add(user)
            db.commit()
            db.refresh(user)
        return user

    payload = decode_token(credentials.credentials)
    username = payload.get("sub")
    if username is None:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")

    return user
