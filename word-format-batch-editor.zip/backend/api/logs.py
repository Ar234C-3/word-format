"""Logs API endpoints."""

from typing import Optional
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.models.log_entry import LogEntry
from backend.schemas.response import UnifiedResponse

router = APIRouter(prefix="/logs", tags=["logs"])


@router.get("")
def list_logs(
    level: Optional[str] = None,
    document: Optional[str] = None,
    action: Optional[str] = None,
    from_date: Optional[str] = None,
    to_date: Optional[str] = None,
    page: int = Query(default=1, ge=1),
    size: int = Query(default=50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """Query logs with filtering."""
    query = db.query(LogEntry)

    if level:
        query = query.filter(LogEntry.level == level.upper())
    if document:
        query = query.filter(LogEntry.document_id == document)
    if action:
        query = query.filter(LogEntry.action == action)
    if from_date:
        try:
            dt = datetime.fromisoformat(from_date)
            query = query.filter(LogEntry.timestamp >= dt)
        except ValueError:
            pass
    if to_date:
        try:
            dt = datetime.fromisoformat(to_date)
            query = query.filter(LogEntry.timestamp <= dt)
        except ValueError:
            pass

    total = query.count()
    logs = query.order_by(LogEntry.timestamp.desc()).offset((page - 1) * size).limit(size).all()

    return UnifiedResponse.success(data={
        "items": [
            {
                "id": l.id, "level": l.level, "action": l.action,
                "document_id": l.document_id, "task_id": l.task_id,
                "node_path": l.node_path, "rule_id": l.rule_id,
                "message": l.message,
                "before_value": l.before_value,
                "after_value": l.after_value,
                "timestamp": l.timestamp.isoformat() if l.timestamp else None,
            }
            for l in logs
        ],
        "total": total,
    })


@router.get("/export")
def export_logs(
    format: str = Query(default="json", regex="^(log|json|csv)$"),
    level: Optional[str] = None,
    document: Optional[str] = None,
    action: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """Export logs in various formats."""
    query = db.query(LogEntry)
    if level:
        query = query.filter(LogEntry.level == level.upper())
    if document:
        query = query.filter(LogEntry.document_id == document)
    if action:
        query = query.filter(LogEntry.action == action)

    logs = query.order_by(LogEntry.timestamp.desc()).limit(10000).all()

    if format == "json":
        import json
        data = [
            {
                "timestamp": l.timestamp.isoformat() if l.timestamp else None,
                "level": l.level, "action": l.action,
                "document_id": l.document_id, "message": l.message,
                "before": l.before_value, "after": l.after_value,
            }
            for l in logs
        ]
        content = json.dumps(data, ensure_ascii=False, indent=2)
        media_type = "application/json"
        filename = "logs.json"
    elif format == "csv":
        import csv
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["timestamp", "level", "action", "document_id", "message", "before", "after"])
        for l in logs:
            writer.writerow([
                l.timestamp.isoformat() if l.timestamp else "",
                l.level, l.action, l.document_id or "",
                l.message or "", str(l.before_value or ""), str(l.after_value or ""),
            ])
        content = output.getvalue()
        media_type = "text/csv"
        filename = "logs.csv"
    else:
        lines = []
        for l in logs:
            ts = l.timestamp.strftime("%Y-%m-%d %H:%M:%S") if l.timestamp else ""
            lines.append(f"[{ts}] [{l.level}] {l.action}: {l.message}")
        content = "\n".join(lines)
        media_type = "text/plain"
        filename = "logs.log"

    return StreamingResponse(
        iter([content]),
        media_type=media_type,
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
