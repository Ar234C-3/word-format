"""Rules API endpoints."""

from fastapi import APIRouter
from backend.schemas.format_spec import FormatRule
from backend.schemas.response import UnifiedResponse
from backend.services.rule_engine import validate_rule

router = APIRouter(prefix="/rules", tags=["rules"])


@router.post("/validate")
def validate(rule: FormatRule):
    """Validate a format rule."""
    errors = validate_rule(rule)
    return UnifiedResponse.success(data={
        "valid": len(errors) == 0,
        "errors": errors,
    })


@router.post("/test")
def test(rule: FormatRule, node_snapshot: dict):
    """Test a rule against a node snapshot."""
    from backend.services.rule_engine import _evaluate_condition
    from backend.schemas.document import DocumentNode, DocumentStructure

    try:
        node = DocumentNode(**node_snapshot)
        # Create a minimal structure for testing
        structure = DocumentStructure(
            document_id="test", total_pages=1,
            sections=[], nodes={node.id: node},
            root_node_ids=[node.id],
        )
        matched = _evaluate_condition(rule.condition, node, structure)
        return UnifiedResponse.success(data={
            "matched": matched,
            "applied_action": rule.action.model_dump() if matched else None,
        })
    except Exception as e:
        return UnifiedResponse.error(code=400, message=str(e))
