"""Documents API endpoints."""

import os
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.dependencies import get_current_user
from backend.models.document import Document
from backend.schemas.document import DocumentResponse, DocumentListResponse
from backend.schemas.response import UnifiedResponse
from backend.services.document_service import (
    save_uploaded_file, get_document, list_documents, delete_document,
)
from backend.services.structure_parser import parse_document_structure
from backend.core.html_renderer import render_structure_html

router = APIRouter(prefix="/documents", tags=["documents"])


@router.post("/upload")
async def upload_document(
    file: UploadFile = File(...),
    tags: str = Query(default=""),
    db: Session = Depends(get_db),
):
    """Upload one or more .docx files."""
    content = await file.read()
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    try:
        doc = save_uploaded_file(content, file.filename, db, tag_list)
        return UnifiedResponse.success(data={
            "id": doc.id,
            "name": doc.name,
            "size": doc.size,
            "pages": doc.pages,
            "status": doc.status,
        })
    except ValueError as e:
        return UnifiedResponse.error(code=400, message=str(e))


@router.get("")
def list_docs(
    page: int = Query(default=1, ge=1),
    size: int = Query(default=20, ge=1, le=100),
    sort: str = Query(default="created_at"),
    status: Optional[str] = None,
    tag: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """List documents with pagination and filtering."""
    docs, total = list_documents(db, page, size, sort, status, tag)
    items = [
        DocumentResponse(
            id=d.id, name=d.name, size=d.size,
            pages=d.pages, status=d.status,
            tags=d.tags or [],
            created_at=d.created_at.isoformat() if d.created_at else None,
        )
        for d in docs
    ]
    return UnifiedResponse.success(data={
        "items": [i.model_dump() for i in items],
        "total": total, "page": page, "size": size,
    })


@router.get("/{doc_id}/structure")
def get_structure(doc_id: str, db: Session = Depends(get_db)):
    """Get document structure tree."""
    doc = get_document(doc_id, db)
    if doc is None:
        return UnifiedResponse.error(code=404, message="Document not found")

    try:
        structure = parse_document_structure(doc.original_path, doc_id)
        return UnifiedResponse.success(data=structure.model_dump())
    except Exception as e:
        return UnifiedResponse.error(code=500, message=f"Parse error: {str(e)}")


@router.get("/{doc_id}/preview")
def get_preview(
    doc_id: str,
    page: int = Query(default=1, ge=1),
    zoom: float = Query(default=1.0, ge=0.5, le=3.0),
    db: Session = Depends(get_db),
):
    """Get HTML preview of a document."""
    doc = get_document(doc_id, db)
    if doc is None:
        return UnifiedResponse.error(code=404, message="Document not found")

    try:
        structure = parse_document_structure(doc.original_path, doc_id)
        html = render_structure_html(structure)
        return UnifiedResponse.success(data={
            "html": html,
            "total_pages": structure.total_pages,
        })
    except Exception as e:
        return UnifiedResponse.error(code=500, message=f"Preview error: {str(e)}")


@router.post("/{doc_id}/download")
def download_document(doc_id: str, db: Session = Depends(get_db)):
    """Download processed (or original) document."""
    doc = get_document(doc_id, db)
    if doc is None:
        return UnifiedResponse.error(code=404, message="Document not found")

    file_path = doc.processed_path if doc.processed_path else doc.original_path
    if not os.path.exists(file_path):
        return UnifiedResponse.error(code=404, message="File not found")

    return FileResponse(
        path=file_path,
        filename=doc.name,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )


@router.post("/batch-download")
def batch_download(document_ids: List[str], db: Session = Depends(get_db)):
    """Download multiple documents as a ZIP."""
    import zipfile
    import tempfile

    docs = db.query(Document).filter(Document.id.in_(document_ids)).all()
    if not docs:
        return UnifiedResponse.error(code=404, message="No documents found")

    # Create temporary ZIP
    tmp = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
        for doc in docs:
            file_path = doc.processed_path if doc.processed_path else doc.original_path
            if file_path and os.path.exists(file_path):
                zf.write(file_path, doc.name)

    return FileResponse(
        path=tmp.name,
        filename="batch_download.zip",
        media_type="application/zip",
    )


@router.delete("/{doc_id}")
def delete_doc(doc_id: str, db: Session = Depends(get_db)):
    """Delete a document."""
    if delete_document(doc_id, db):
        return UnifiedResponse.success(data={"deleted": True})
    return UnifiedResponse.error(code=404, message="Document not found")
