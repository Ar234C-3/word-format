"""WebSocket endpoints for real-time progress and logs."""

import asyncio
import json
from typing import Dict, Set

from fastapi import WebSocket, WebSocketDisconnect
from backend.models.task import Task


class ConnectionManager:
    """Manages WebSocket connections."""

    def __init__(self):
        self.progress_connections: Dict[str, Set[WebSocket]] = {}
        self.log_connections: Set[WebSocket] = set()

    async def connect_progress(self, websocket: WebSocket, task_id: str):
        await websocket.accept()
        if task_id not in self.progress_connections:
            self.progress_connections[task_id] = set()
        self.progress_connections[task_id].add(websocket)

    async def connect_logs(self, websocket: WebSocket):
        await websocket.accept()
        self.log_connections.add(websocket)

    def disconnect_progress(self, websocket: WebSocket, task_id: str):
        if task_id in self.progress_connections:
            self.progress_connections[task_id].discard(websocket)

    def disconnect_logs(self, websocket: WebSocket):
        self.log_connections.discard(websocket)

    async def send_progress(self, task_id: str, data: dict):
        if task_id in self.progress_connections:
            dead = set()
            for ws in self.progress_connections[task_id]:
                try:
                    await ws.send_json(data)
                except Exception:
                    dead.add(ws)
            self.progress_connections[task_id] -= dead

    async def send_log(self, data: dict):
        dead = set()
        for ws in self.log_connections:
            try:
                await ws.send_json(data)
            except Exception:
                dead.add(ws)
        self.log_connections -= dead


manager = ConnectionManager()


def setup_websocket_routes(app):
    """Register WebSocket routes on the FastAPI app."""

    @app.websocket("/ws/v1/progress")
    async def progress_ws(websocket: WebSocket, task_id: str = ""):
        if not task_id:
            await websocket.close(code=4000)
            return

        await manager.connect_progress(websocket, task_id)
        try:
            while True:
                # Keep connection alive, client can send ping
                data = await websocket.receive_text()
                if data == "ping":
                    await websocket.send_text("pong")
        except WebSocketDisconnect:
            manager.disconnect_progress(websocket, task_id)

    @app.websocket("/ws/v1/logs")
    async def logs_ws(websocket: WebSocket):
        await manager.connect_logs(websocket)
        try:
            while True:
                data = await websocket.receive_text()
                if data == "ping":
                    await websocket.send_text("pong")
        except WebSocketDisconnect:
            manager.disconnect_logs(websocket)
