"""Auth API endpoints."""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.dependencies import (
    hash_password, verify_password,
    create_access_token, create_refresh_token, decode_token,
)
from backend.models.user import User
from backend.schemas.response import UnifiedResponse

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


@router.post("/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == req.username).first()
    if user is None or not verify_password(req.password, user.password_hash):
        return UnifiedResponse.error(code=401, message="Invalid credentials")

    access_token = create_access_token({"sub": user.username})
    refresh_token = create_refresh_token({"sub": user.username})

    return UnifiedResponse.success(data={
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_in": 86400,
    })


@router.post("/refresh")
def refresh(req: RefreshRequest, db: Session = Depends(get_db)):
    payload = decode_token(req.refresh_token)
    if payload.get("type") != "refresh":
        return UnifiedResponse.error(code=401, message="Invalid refresh token")

    username = payload.get("sub")
    user = db.query(User).filter(User.username == username).first()
    if user is None:
        return UnifiedResponse.error(code=401, message="User not found")

    access_token = create_access_token({"sub": user.username})
    return UnifiedResponse.success(data={
        "access_token": access_token,
        "expires_in": 86400,
    })
