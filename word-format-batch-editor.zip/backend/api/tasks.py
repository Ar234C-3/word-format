"""Tasks API endpoints."""

from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.schemas.task import TaskCreate, TaskStatus
from backend.schemas.response import UnifiedResponse
from backend.services.task_service import (
    create_task, get_task, list_tasks,
    pause_task, resume_task, cancel_task, rollback_task,
    update_task_progress,
)
from backend.services.document_service import get_document
from backend.services.format_engine import apply_format_rules
from backend.services.diff_service import generate_diff_report
from backend.schemas.format_spec import FormatRule

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.post("/dry-run")
def dry_run(data: TaskCreate, db: Session = Depends(get_db)):
    """Dry-run: simulate processing without modifying files."""
    results = []
    would_modify = 0
    would_skip = 0
    would_error = 0

    for doc_id in data.document_ids:
        doc = get_document(doc_id, db)
        if doc is None:
            results.append({
                "document_id": doc_id,
                "document_name": "unknown",
                "status": "ERROR",
                "error_message": "Document not found",
            })
            would_error += 1
            continue

        try:
            rules = [FormatRule(**r) if isinstance(r, dict) else r for r in data.rules]
            from backend.services.structure_parser import parse_document_structure
            from backend.services.rule_engine import match_rules

            structure = parse_document_structure(doc.original_path, doc_id)
            matched = match_rules(structure, rules)

            mod_count = sum(len(v) for v in matched.values())
            if mod_count > 0:
                would_modify += 1
            else:
                would_skip += 1

            results.append({
                "document_id": doc_id,
                "document_name": doc.name,
                "status": "WOULD_MODIFY" if mod_count > 0 else "NO_CHANGES",
                "modifications_count": mod_count,
            })
        except Exception as e:
            results.append({
                "document_id": doc_id,
                "document_name": doc.name,
                "status": "ERROR",
                "error_message": str(e),
            })
            would_error += 1

    return UnifiedResponse.success(data={
        "total_documents": len(data.document_ids),
        "would_modify": would_modify,
        "would_skip": would_skip,
        "would_error": would_error,
        "estimated_seconds": len(data.document_ids) * 2,
        "results": results,
    })


@router.post("")
def create(data: TaskCreate, db: Session = Depends(get_db)):
    """Create and start a batch processing task."""
    task = create_task(data, db)

    # Start processing in background (using threading for simplicity)
    import threading
    rules_data = [r.model_dump() if hasattr(r, 'model_dump') else r for r in data.rules]

    def run_task():
        from backend.tasks.process_task import process_batch_task
        process_batch_task(task.id, data.document_ids, rules_data)

    thread = threading.Thread(target=run_task, daemon=True)
    thread.start()

    return UnifiedResponse.success(data={
        "task_id": task.id,
        "status": task.status,
        "total": task.total_documents,
        "estimated_seconds": task.total_documents * 2,
    })


@router.get("/{task_id}")
def get_status(task_id: str, db: Session = Depends(get_db)):
    task = get_task(task_id, db)
    if task is None:
        return UnifiedResponse.error(code=404, message="Task not found")
    return UnifiedResponse.success(data={
        "id": task.id, "name": task.name, "status": task.status,
        "total_documents": task.total_documents,
        "processed_documents": task.processed_documents,
        "success_count": task.success_count,
        "error_count": task.error_count,
        "skipped_count": task.skipped_count,
        "progress": task.progress,
        "estimated_seconds": task.estimated_seconds,
        "error_message": task.error_message,
        "created_at": task.created_at.isoformat() if task.created_at else None,
        "started_at": task.started_at.isoformat() if task.started_at else None,
        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
    })


@router.get("")
def list_all(
    page: int = Query(default=1, ge=1),
    size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    tasks, total = list_tasks(db, page, size)
    return UnifiedResponse.success(data={
        "items": [
            {
                "id": t.id, "name": t.name, "status": t.status,
                "total_documents": t.total_documents,
                "processed_documents": t.processed_documents,
                "progress": t.progress,
                "created_at": t.created_at.isoformat() if t.created_at else None,
            }
            for t in tasks
        ],
        "total": total, "page": page, "size": size,
    })


@router.put("/{task_id}/pause")
def pause(task_id: str, db: Session = Depends(get_db)):
    if pause_task(task_id, db):
        return UnifiedResponse.success(data={"status": "PAUSED"})
    return UnifiedResponse.error(code=400, message="Cannot pause task")


@router.put("/{task_id}/resume")
def resume(task_id: str, db: Session = Depends(get_db)):
    if resume_task(task_id, db):
        return UnifiedResponse.success(data={"status": "RUNNING"})
    return UnifiedResponse.error(code=400, message="Cannot resume task")


@router.delete("/{task_id}")
def cancel(task_id: str, db: Session = Depends(get_db)):
    if cancel_task(task_id, db):
        return UnifiedResponse.success(data={"status": "CANCELLED"})
    return UnifiedResponse.error(code=400, message="Cannot cancel task")


@router.get("/{task_id}/results")
def get_results(task_id: str, db: Session = Depends(get_db)):
    task = get_task(task_id, db)
    if task is None:
        return UnifiedResponse.error(code=404, message="Task not found")
    return UnifiedResponse.success(data=task.result_json or [])


@router.get("/{task_id}/diff")
def get_diff(task_id: str, db: Session = Depends(get_db)):
    task = get_task(task_id, db)
    if task is None:
        return UnifiedResponse.error(code=404, message="Task not found")

    config_data = task.config_json or {}
    document_ids = config_data.get("document_ids", [])
    diffs = []

    for doc_id in document_ids:
        doc = get_document(doc_id, db)
        if doc and doc.processed_path and doc.snapshot_path:
            from backend.models.log_entry import LogEntry
            logs = db.query(LogEntry).filter(
                LogEntry.task_id == task_id,
                LogEntry.document_id == doc_id,
            ).all()

            from backend.schemas.task import Modification
            from datetime import datetime
            mods = [
                Modification(
                    node_path=l.node_path or "",
                    rule_id=l.rule_id,
                    property_name=l.message or "",
                    before_value=l.before_value,
                    after_value=l.after_value,
                    timestamp=l.timestamp or datetime.utcnow(),
                )
                for l in logs
            ]

            diff = generate_diff_report(
                doc_id, doc.name, doc.original_path,
                doc.processed_path, mods,
            )
            diffs.append(diff.model_dump())

    return UnifiedResponse.success(data=diffs)


@router.post("/{task_id}/rollback")
def rollback(task_id: str, node_ids: List[str] = [], db: Session = Depends(get_db)):
    count = rollback_task(task_id, node_ids, db)
    return UnifiedResponse.success(data={"rolled_back_count": count})
