"""API router - aggregates all sub-routers."""

from fastapi import APIRouter
from backend.api.auth import router as auth_router
from backend.api.documents import router as documents_router
from backend.api.templates import router as templates_router
from backend.api.tasks import router as tasks_router
from backend.api.rules import router as rules_router
from backend.api.logs import router as logs_router

router = APIRouter(prefix="/api/v1")

router.include_router(auth_router)
router.include_router(documents_router)
router.include_router(templates_router)
router.include_router(tasks_router)
router.include_router(rules_router)
router.include_router(logs_router)
