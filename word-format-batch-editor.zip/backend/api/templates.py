"""Templates API endpoints."""

from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.database import get_db
from backend.schemas.template import TemplateCreate, TemplateUpdate, TemplateResponse
from backend.schemas.response import UnifiedResponse
from backend.services.template_service import (
    create_template, get_template, list_templates,
    update_template, delete_template,
)

router = APIRouter(prefix="/templates", tags=["templates"])


@router.post("")
def create(data: TemplateCreate, db: Session = Depends(get_db)):
    template = create_template(data, db)
    return UnifiedResponse.success(data={
        "id": template.id, "name": template.name,
        "description": template.description,
        "format_rules": template.format_rules,
        "numbering_config": template.numbering_config,
        "table_config": template.table_config,
        "is_default": template.is_default,
    })


@router.get("")
def list_all(db: Session = Depends(get_db)):
    templates = list_templates(db)
    return UnifiedResponse.success(data=[
        {
            "id": t.id, "name": t.name, "description": t.description,
            "format_rules": t.format_rules, "numbering_config": t.numbering_config,
            "table_config": t.table_config, "is_default": t.is_default,
        }
        for t in templates
    ])


@router.get("/{template_id}")
def get_one(template_id: str, db: Session = Depends(get_db)):
    template = get_template(template_id, db)
    if template is None:
        return UnifiedResponse.error(code=404, message="Template not found")
    return UnifiedResponse.success(data={
        "id": template.id, "name": template.name, "description": template.description,
        "format_rules": template.format_rules, "numbering_config": template.numbering_config,
        "table_config": template.table_config, "is_default": template.is_default,
    })


@router.put("/{template_id}")
def update(template_id: str, data: TemplateUpdate, db: Session = Depends(get_db)):
    template = update_template(template_id, data, db)
    if template is None:
        return UnifiedResponse.error(code=404, message="Template not found")
    return UnifiedResponse.success(data={
        "id": template.id, "name": template.name,
    })


@router.delete("/{template_id}")
def delete(template_id: str, db: Session = Depends(get_db)):
    if delete_template(template_id, db):
        return UnifiedResponse.success(data={"deleted": True})
    return UnifiedResponse.error(code=404, message="Template not found")
