"""FastAPI main entry point."""

import os
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from backend.config import get_config
from backend.database import init_db
from backend.api.router import router
from backend.api.ws import setup_websocket_routes
from backend.utils.logger import setup_logger

# Setup logging
logger = setup_logger()

# Track start time for uptime
_start_time = time.time()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan - startup and shutdown."""
    logger.info("Starting Word Format Batch Editor...")
    init_db()
    logger.info("Database initialized")

    # Ensure storage directories exist
    config = get_config()
    storage = Path(config.storage.base_path)
    for subdir in ["original", "processed", "snapshots", "temp"]:
        (storage / subdir).mkdir(parents=True, exist_ok=True)

    yield

    logger.info("Shutting down...")


app = FastAPI(
    title="Word Format Batch Editor",
    version="1.0.0",
    description="Web-based batch Word document format processor",
    lifespan=lifespan,
)

# CORS
config = get_config()
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.security.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routes
app.include_router(router)

# WebSocket routes
setup_websocket_routes(app)


@app.get("/api/v1/health")
def health():
    """Health check endpoint."""
    return {
        "status": "ok",
        "version": "1.0.0",
        "uptime": int(time.time() - _start_time),
    }


# Serve frontend
frontend_dist = Path(__file__).parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    # Serve index.html for all non-API routes (SPA)
    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        # Try to serve static file first
        file_path = frontend_dist / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        # Fall back to index.html for SPA routing
        index = frontend_dist / "index.html"
        if index.exists():
            return FileResponse(str(index))
        return {"message": "Frontend not built. Run: cd frontend && npm run build"}
else:
    @app.get("/")
    def root():
        return {
            "message": "Word Format Batch Editor API",
            "docs": "/docs",
            "health": "/api/v1/health",
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.main:app",
        host=config.server.host,
        port=config.server.port,
        reload=False,
        workers=config.server.workers,
    )
