"""Log entry model."""

import uuid
from datetime import datetime

from sqlalchemy import Column, String, Integer, DateTime, Text, JSON
from backend.database import Base


class LogEntry(Base):
    __tablename__ = "log_entries"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    level = Column(String(10), nullable=False, index=True)  # DEBUG/INFO/WARN/ERROR/FATAL
    action = Column(String(50), nullable=False, index=True)
    document_id = Column(String(36), nullable=True, index=True)
    task_id = Column(String(36), nullable=True, index=True)
    node_path = Column(String(500), nullable=True)
    rule_id = Column(String(36), nullable=True)
    message = Column(Text, nullable=True)
    before_value = Column(JSON, nullable=True)
    after_value = Column(JSON, nullable=True)
    extra_data = Column(JSON, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
