"""Document model."""

import uuid
from datetime import datetime

from sqlalchemy import Column, String, Integer, DateTime, Text, JSON
from backend.database import Base


class Document(Base):
    __tablename__ = "documents"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(500), nullable=False)
    original_path = Column(String(1000), nullable=False)
    processed_path = Column(String(1000), nullable=True)
    snapshot_path = Column(String(1000), nullable=True)
    size = Column(Integer, nullable=False)
    pages = Column(Integer, default=0)
    status = Column(String(20), default="UPLOADED")  # UPLOADED/PROCESSING/DONE/ERROR/SKIPPED
    error_message = Column(Text, nullable=True)
    sha256 = Column(String(64), nullable=True)
    tags = Column(JSON, default=list)
    structure_json = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
