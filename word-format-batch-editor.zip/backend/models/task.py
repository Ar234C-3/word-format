"""Task model."""

import uuid
from datetime import datetime

from sqlalchemy import Column, String, Integer, Float, DateTime, Text, JSON
from backend.database import Base


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=True)
    status = Column(String(20), default="PENDING")  # PENDING/RUNNING/PAUSED/DONE/FAILED/CANCELLED
    total_documents = Column(Integer, default=0)
    processed_documents = Column(Integer, default=0)
    success_count = Column(Integer, default=0)
    error_count = Column(Integer, default=0)
    skipped_count = Column(Integer, default=0)
    progress = Column(Float, default=0.0)
    config_json = Column(JSON, nullable=True)  # TaskCreate payload
    result_json = Column(JSON, nullable=True)
    error_message = Column(Text, nullable=True)
    celery_task_id = Column(String(200), nullable=True)
    estimated_seconds = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
