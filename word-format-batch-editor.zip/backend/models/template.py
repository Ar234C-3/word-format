"""Template model."""

import uuid
from datetime import datetime

from sqlalchemy import Column, String, DateTime, Text, JSON, Boolean
from backend.database import Base


class Template(Base):
    __tablename__ = "templates"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=False)
    description = Column(Text, nullable=True)
    format_rules = Column(JSON, default=list)
    numbering_config = Column(JSON, nullable=True)
    table_config = Column(JSON, nullable=True)
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
