"""OOXML writer - XML modification and ZIP repackaging."""

import os
import shutil
import tempfile
import zipfile
from typing import Dict, Set
from lxml import etree


NSMAP = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "w14": "http://schemas.microsoft.com/office/word/2010/wordml",
    "w15": "http://schemas.microsoft.com/office/word/2012/wordml",
}


class OOXMLWriter:
    """Modifies OOXML content and repackages as .docx."""

    def __init__(self, source_path: str, output_path: str):
        self.source_path = source_path
        self.output_path = output_path
        self._modified: Dict[str, etree._Element] = {}
        self._temp_dir: str = ""

    def __enter__(self):
        self._temp_dir = tempfile.mkdtemp()
        return self

    def __exit__(self, *args):
        if self._temp_dir and os.path.exists(self._temp_dir):
            shutil.rmtree(self._temp_dir)

    def set_xml(self, name: str, element: etree._Element):
        """Store modified XML for later writing."""
        self._modified[name] = element

    def _get_all_entries(self) -> Set[str]:
        """Get all entry names from source docx."""
        with zipfile.ZipFile(self.source_path, "r") as zf:
            return set(zf.namelist())

    def save(self):
        """Repackage the docx with modified XML files."""
        # Read all entries from source
        with zipfile.ZipFile(self.source_path, "r") as src_zip:
            all_entries = src_zip.namelist()

            with zipfile.ZipFile(self.output_path, "w", zipfile.ZIP_DEFLATED) as out_zip:
                for entry in all_entries:
                    if entry in self._modified:
                        # Write modified XML
                        xml_bytes = etree.tostring(
                            self._modified[entry],
                            xml_declaration=True,
                            encoding="UTF-8",
                            standalone=True,
                        )
                        out_zip.writestr(entry, xml_bytes)
                    else:
                        # Copy original
                        data = src_zip.read(entry)
                        out_zip.writestr(entry, data)


def get_or_create_child(parent: etree._Element, tag: str, nsmap: dict = None) -> etree._Element:
    """Get existing child element or create one."""
    child = parent.find(tag, nsmap)
    if child is None:
        child = etree.SubElement(parent, tag)
    return child


def set_attribute(element: etree._Element, attr: str, value: str, nsmap: dict = None):
    """Set an attribute on an element, handling namespaces."""
    if nsmap and ":" in attr:
        prefix, local = attr.split(":", 1)
        ns = nsmap.get(prefix)
        if ns:
            attr_key = f"{{{ns}}}{local}"
        else:
            attr_key = attr
    else:
        attr_key = attr
    element.set(attr_key, value)


def twips_to_pt(twips: int) -> float:
    """Convert twips (1/20 pt) to points."""
    return twips / 20.0


def pt_to_twips(pt: float) -> int:
    """Convert points to twips."""
    return int(pt * 20)


def pt_to_emu(pt: float) -> int:
    """Convert points to EMU (English Metric Units)."""
    return int(pt * 12700)


def half_pt_to_pt(half_pt: int) -> float:
    """Convert half-points to points."""
    return half_pt / 2.0


def pt_to_half_pt(pt: float) -> int:
    """Convert points to half-points."""
    return int(pt * 2)
