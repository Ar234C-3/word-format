"""Styles parser - parses word/styles.xml."""

from typing import Dict, Optional, List
from lxml import etree
from backend.core.ooxml_writer import NSMAP


class StyleInfo:
    """Represents a parsed style definition."""

    def __init__(self, style_id: str, name: str, style_type: str,
                 based_on: Optional[str] = None, font_cn: Optional[str] = None,
                 font_en: Optional[str] = None, font_size: Optional[float] = None,
                 bold: Optional[bool] = None, italic: Optional[bool] = None,
                 heading_level: Optional[int] = None):
        self.style_id = style_id
        self.name = name
        self.style_type = style_type  # paragraph, character, table, numbering
        self.based_on = based_on
        self.font_cn = font_cn
        self.font_en = font_en
        self.font_size = font_size
        self.bold = bold
        self.italic = italic
        self.heading_level = heading_level


def parse_styles(styles_xml: etree._Element) -> Dict[str, StyleInfo]:
    """Parse all style definitions from styles.xml."""
    styles = {}
    w = NSMAP["w"]

    for style_el in styles_xml.findall(f"{{{w}}}style"):
        style_id = style_el.get(f"{{{w}}}styleId", "")
        style_type = style_el.get(f"{{{w}}}type", "paragraph")
        name_el = style_el.find(f"{{{w}}}name")
        name = name_el.get(f"{{{w}}}val", "") if name_el is not None else ""
        based_on_el = style_el.find(f"{{{w}}}basedOn")
        based_on = based_on_el.get(f"{{{w}}}val", "") if based_on_el is not None else None

        # Parse font properties
        rpr = style_el.find(f"{{{w}}}rPr")
        font_cn = font_en = None
        font_size = None
        bold = italic = None

        if rpr is not None:
            fonts_el = rpr.find(f"{{{w}}}rFonts")
            if fonts_el is not None:
                font_cn = fonts_el.get(f"{{{w}}}eastAsia")
                font_en = fonts_el.get(f"{{{w}}}ascii")
            sz_el = rpr.find(f"{{{w}}}sz")
            if sz_el is not None:
                try:
                    font_size = int(sz_el.get(f"{{{w}}}val", "0")) / 2.0
                except ValueError:
                    pass
            b_el = rpr.find(f"{{{w}}}b")
            if b_el is not None:
                val = b_el.get(f"{{{w}}}val", "true")
                bold = val.lower() != "false"
            i_el = rpr.find(f"{{{w}}}i")
            if i_el is not None:
                val = i_el.get(f"{{{w}}}val", "true")
                italic = val.lower() != "false"

        # Heading level
        heading_level = None
        if name.lower().startswith("heading"):
            try:
                heading_level = int(name.lower().replace("heading", "").strip())
            except ValueError:
                pass

        styles[style_id] = StyleInfo(
            style_id=style_id, name=name, style_type=style_type,
            based_on=based_on, font_cn=font_cn, font_en=font_en,
            font_size=font_size, bold=bold, italic=italic,
            heading_level=heading_level,
        )

    return styles


def resolve_style_chain(styles: Dict[str, StyleInfo], style_id: str) -> dict:
    """Resolve a style's full properties by following the basedOn chain."""
    resolved = {}
    visited = set()

    current_id = style_id
    while current_id and current_id not in visited:
        visited.add(current_id)
        style = styles.get(current_id)
        if style is None:
            break

        # Only set if not already set (most specific wins)
        if style.font_cn and "font_cn" not in resolved:
            resolved["font_cn"] = style.font_cn
        if style.font_en and "font_en" not in resolved:
            resolved["font_en"] = style.font_en
        if style.font_size and "font_size" not in resolved:
            resolved["font_size"] = style.font_size
        if style.bold is not None and "bold" not in resolved:
            resolved["bold"] = style.bold
        if style.italic is not None and "italic" not in resolved:
            resolved["italic"] = style.italic

        current_id = style.based_on

    return resolved
