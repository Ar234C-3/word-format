"""HTML renderer - converts DocumentStructure to HTML preview."""

import base64
from typing import Optional
from backend.schemas.document import DocumentStructure, DocumentNode
from backend.schemas.format_spec import FormatSpec
from backend.core.ooxml_writer import NSMAP


def format_to_css(fmt: FormatSpec) -> str:
    """Convert FormatSpec to inline CSS string."""
    parts = []
    if fmt.font_cn or fmt.font_en:
        fonts = []
        if fmt.font_en:
            fonts.append(f"'{fmt.font_en}'")
        if fmt.font_cn:
            fonts.append(f"'{fmt.font_cn}'")
        parts.append(f"font-family: {', '.join(fonts)}")
    if fmt.font_size:
        parts.append(f"font-size: {fmt.font_size}pt")
    if fmt.font_color:
        parts.append(f"color: {fmt.font_color}")
    if fmt.bold:
        parts.append("font-weight: bold")
    if fmt.italic:
        parts.append("font-style: italic")
    if fmt.underline:
        if fmt.underline == "single":
            parts.append("text-decoration: underline")
        elif fmt.underline == "double":
            parts.append("text-decoration: underline double")
        elif fmt.underline == "wave":
            parts.append("text-decoration: underline wavy")
    if fmt.alignment:
        parts.append(f"text-align: {fmt.alignment}")
    if fmt.line_spacing:
        parts.append(f"line-height: {fmt.line_spacing}")
    if fmt.space_before:
        parts.append(f"margin-top: {fmt.space_before}pt")
    if fmt.space_after:
        parts.append(f"margin-bottom: {fmt.space_after}pt")
    if fmt.first_line_indent:
        parts.append(f"text-indent: {fmt.first_line_indent}pt")
    return "; ".join(parts)


def render_node_html(node: DocumentNode) -> str:
    """Render a single node to HTML."""
    css = format_to_css(node.current_format)
    style_attr = f' style="{css}"' if css else ""

    if node.type == "heading":
        level = min(max(node.level, 1), 6)
        return f'<h{level} data-node-id="{node.id}"{style_attr}>{_escape(node.content_preview)}</h{level}>'
    elif node.type == "paragraph":
        return f'<p data-node-id="{node.id}"{style_attr}>{_escape(node.content_preview)}</p>'
    elif node.type == "list_item":
        indent = node.level * 24
        return f'<div data-node-id="{node.id}"{style_attr} style="margin-left: {indent}px; {css}">{_escape(node.content_preview)}</div>'
    elif node.type == "table":
        if node.table_info:
            return _render_table(node)
        return f'<div data-node-id="{node.id}">[Table]</div>'
    elif node.type == "image":
        return f'<div data-node-id="{node.id}"{style_attr}>[Image]</div>'
    elif node.type == "page_break":
        return '<hr style="page-break-after: always; border: 1px dashed #ccc;">'
    elif node.type == "section_break":
        return '<hr style="border: 1px solid #999;">'
    else:
        return f'<div data-node-id="{node.id}"{style_attr}>{_escape(node.content_preview)}</div>'


def _render_table(node: DocumentNode) -> str:
    """Render a table node with merged cells."""
    info = node.table_info
    if info is None:
        return ""

    # Build merge map
    merge_map = {}
    for mc in info.merged_cells:
        for r in range(mc.row, mc.row + mc.row_span):
            for c in range(mc.col, mc.col + mc.col_span):
                if r != mc.row or c != mc.col:
                    merge_map[(r, c)] = "skip"
                else:
                    merge_map[(r, c)] = (mc.row_span, mc.col_span)

    html = f'<table data-node-id="{node.id}" border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; width: 100%;">'
    for r in range(info.rows):
        html += "<tr>"
        for c in range(info.cols):
            if (r, c) in merge_map and merge_map[(r, c)] == "skip":
                continue
            rowspan = colspan = ""
            if (r, c) in merge_map and isinstance(merge_map[(r, c)], tuple):
                rs, cs = merge_map[(r, c)]
                if rs > 1:
                    rowspan = f' rowspan="{rs}"'
                if cs > 1:
                    colspan = f' colspan="{cs}"'
            tag = "th" if r == 0 and info.has_header_row else "td"
            html += f'<{tag}{rowspan}{colspan} style="border: 1px solid #ccc; padding: 4px;">&nbsp;</{tag}>'
        html += "</tr>"
    html += "</table>"
    return html


def render_structure_html(structure: DocumentStructure) -> str:
    """Render full document structure to an HTML string."""
    css = """
    body { font-family: 'SimSun', serif; font-size: 12pt; line-height: 1.5; max-width: 800px; margin: 0 auto; padding: 20px; }
    h1 { font-size: 22pt; } h2 { font-size: 16pt; } h3 { font-size: 14pt; }
    table { border-collapse: collapse; } td, th { border: 1px solid #ccc; padding: 4px; }
    """

    html_parts = [f"<!DOCTYPE html><html><head><meta charset='utf-8'><style>{css}</style></head><body>"]

    for node_id in structure.root_node_ids:
        node = structure.nodes.get(node_id)
        if node:
            html_parts.append(render_node_html(node))

    html_parts.append("</body></html>")
    return "\n".join(html_parts)


def _escape(text: str) -> str:
    """Escape HTML special characters."""
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
