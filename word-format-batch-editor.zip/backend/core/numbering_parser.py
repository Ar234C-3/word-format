"""Numbering parser - parses word/numbering.xml."""

from typing import Dict, List, Optional
from lxml import etree
from backend.core.ooxml_writer import NSMAP


class NumLevel:
    """Represents a single numbering level definition."""

    def __init__(self, ilvl: int, fmt: str = "decimal", text: str = "",
                 start: int = 1, font_cn: Optional[str] = None,
                 font_en: Optional[str] = None, font_size: Optional[float] = None,
                 indent_left: Optional[float] = None, hanging: Optional[float] = None):
        self.ilvl = ilvl
        self.fmt = fmt  # numFmt value: decimal, upperRoman, etc.
        self.text = text  # levelText pattern e.g. "%1."
        self.start = start
        self.font_cn = font_cn
        self.font_en = font_en
        self.font_size = font_size
        self.indent_left = indent_left
        self.hanging = hanging


class AbstractNum:
    """Represents an abstractNum definition."""

    def __init__(self, abstract_num_id: int, levels: List[NumLevel] = None,
                 name: Optional[str] = None):
        self.abstract_num_id = abstract_num_id
        self.levels: Dict[int, NumLevel] = {}
        if levels:
            for lvl in levels:
                self.levels[lvl.ilvl] = lvl
        self.name = name


class NumMapping:
    """Maps numId to abstractNumId with optional overrides."""

    def __init__(self, num_id: int, abstract_num_id: int,
                 level_overrides: Dict[int, NumLevel] = None):
        self.num_id = num_id
        self.abstract_num_id = abstract_num_id
        self.level_overrides: Dict[int, NumLevel] = level_overrides or {}


class NumberingConfig:
    """Complete numbering configuration parsed from numbering.xml."""

    def __init__(self):
        self.abstract_nums: Dict[int, AbstractNum] = {}
        self.num_mappings: Dict[int, NumMapping] = {}

    def get_level(self, num_id: int, ilvl: int) -> Optional[NumLevel]:
        """Get the effective level definition for a given numId and ilvl."""
        mapping = self.num_mappings.get(num_id)
        if mapping is None:
            return None

        # Check overrides first
        if ilvl in mapping.level_overrides:
            return mapping.level_overrides[ilvl]

        # Fall back to abstract num
        abstract = self.abstract_nums.get(mapping.abstract_num_id)
        if abstract is None:
            return None

        return abstract.levels.get(ilvl)


def parse_numbering(numbering_xml: etree._Element) -> NumberingConfig:
    """Parse numbering.xml into NumberingConfig."""
    config = NumberingConfig()
    w = NSMAP["w"]

    # Parse abstractNum definitions
    for abs_el in numbering_xml.findall(f"{{{w}}}abstractNum"):
        abs_id_str = abs_el.get(f"{{{w}}}abstractNumId", "0")
        try:
            abs_id = int(abs_id_str)
        except ValueError:
            continue

        name_el = abs_el.find(f"{{{w}}}name")
        name = name_el.get(f"{{{w}}}val", "") if name_el is not None else None

        abstract = AbstractNum(abstract_num_id=abs_id, name=name)

        for lvl_el in abs_el.findall(f"{{{w}}}lvl"):
            ilvl_str = lvl_el.get(f"{{{w}}}ilvl", "0")
            try:
                ilvl = int(ilvl_str)
            except ValueError:
                continue

            # numFmt
            fmt_el = lvl_el.find(f"{{{w}}}numFmt")
            fmt = fmt_el.get(f"{{{w}}}val", "decimal") if fmt_el is not None else "decimal"

            # levelText
            text_el = lvl_el.find(f"{{{w}}}lvlText")
            text = text_el.get(f"{{{w}}}val", "") if text_el is not None else ""

            # start
            start_el = lvl_el.find(f"{{{w}}}start")
            start = 1
            if start_el is not None:
                try:
                    start = int(start_el.get(f"{{{w}}}val", "1"))
                except ValueError:
                    pass

            # Font properties
            rpr = lvl_el.find(f"{{{w}}}rPr")
            font_cn = font_en = None
            font_size = None
            indent_left = hanging = None

            if rpr is not None:
                fonts_el = rpr.find(f"{{{w}}}rFonts")
                if fonts_el is not None:
                    font_cn = fonts_el.get(f"{{{w}}}eastAsia")
                    font_en = fonts_el.get(f"{{{w}}}ascii")
                sz_el = rpr.find(f"{{{w}}}sz")
                if sz_el is not None:
                    try:
                        font_size = int(sz_el.get(f"{{{w}}}val", "0")) / 2.0
                    except ValueError:
                        pass

            # Indentation from pPr
            ppr = lvl_el.find(f"{{{w}}}pPr")
            if ppr is not None:
                ind_el = ppr.find(f"{{{w}}}ind")
                if ind_el is not None:
                    left_val = ind_el.get(f"{{{w}}}left")
                    hang_val = ind_el.get(f"{{{w}}}hanging")
                    if left_val:
                        try:
                            indent_left = int(left_val) / 20.0  # twips to pt
                        except ValueError:
                            pass
                    if hang_val:
                        try:
                            hanging = int(hang_val) / 20.0
                        except ValueError:
                            pass

            abstract.levels[ilvl] = NumLevel(
                ilvl=ilvl, fmt=fmt, text=text, start=start,
                font_cn=font_cn, font_en=font_en, font_size=font_size,
                indent_left=indent_left, hanging=hanging,
            )

        config.abstract_nums[abs_id] = abstract

    # Parse num mappings
    for num_el in numbering_xml.findall(f"{{{w}}}num"):
        num_id_str = num_el.get(f"{{{w}}}numId", "0")
        try:
            num_id = int(num_id_str)
        except ValueError:
            continue

        abs_ref_el = num_el.find(f"{{{w}}}abstractNumId")
        if abs_ref_el is None:
            continue

        abs_ref_str = abs_ref_el.get(f"{{{w}}}val", "0")
        try:
            abs_ref = int(abs_ref_str)
        except ValueError:
            continue

        overrides = {}
        for lvl_ovr in num_el.findall(f"{{{w}}}lvlOverride"):
            ilvl_str = lvl_ovr.get(f"{{{w}}}ilvl", "0")
            try:
                ilvl = int(ilvl_str)
            except ValueError:
                continue

            # If there's a startOverride, create a simple override level
            start_ovr = lvl_ovr.find(f"{{{w}}}startOverride")
            if start_ovr is not None:
                start_val = 1
                try:
                    start_val = int(start_ovr.get(f"{{{w}}}val", "1"))
                except ValueError:
                    pass
                overrides[ilvl] = NumLevel(ilvl=ilvl, start=start_val)

        config.num_mappings[num_id] = NumMapping(
            num_id=num_id, abstract_num_id=abs_ref, level_overrides=overrides,
        )

    return config
