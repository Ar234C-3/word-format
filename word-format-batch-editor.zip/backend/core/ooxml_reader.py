"""OOXML reader - ZIP extraction and XML parsing."""

import zipfile
import os
from typing import Dict, Optional
from lxml import etree


class OOXMLReader:
    """Reads .docx files by extracting OOXML content."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self._zip: Optional[zipfile.ZipFile] = None
        self._xml_cache: Dict[str, etree._Element] = {}

    def open(self):
        self._zip = zipfile.ZipFile(self.file_path, "r")
        return self

    def close(self):
        if self._zip:
            self._zip.close()
            self._zip = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *args):
        self.close()

    def get_xml(self, name: str) -> etree._Element:
        """Parse and cache an XML entry from the docx."""
        if name not in self._xml_cache:
            if self._zip is None:
                raise RuntimeError("Reader not opened")
            data = self._zip.read(name)
            self._xml_cache[name] = etree.fromstring(data)
        return self._xml_cache[name]

    def get_document_xml(self) -> etree._Element:
        return self.get_xml("word/document.xml")

    def get_styles_xml(self) -> Optional[etree._Element]:
        try:
            return self.get_xml("word/styles.xml")
        except KeyError:
            return None

    def get_numbering_xml(self) -> Optional[etree._Element]:
        try:
            return self.get_xml("word/numbering.xml")
        except KeyError:
            return None

    def get_headers(self) -> Dict[str, etree._Element]:
        """Get all header XML files."""
        headers = {}
        if self._zip is None:
            return headers
        for name in self._zip.namelist():
            if name.startswith("word/header") and name.endswith(".xml"):
                headers[name] = self.get_xml(name)
        return headers

    def get_footers(self) -> Dict[str, etree._Element]:
        """Get all footer XML files."""
        footers = {}
        if self._zip is None:
            return footers
        for name in self._zip.namelist():
            if name.startswith("word/footer") and name.endswith(".xml"):
                footers[name] = self.get_xml(name)
        return footers

    def get_content_types(self) -> etree._Element:
        return self.get_xml("[Content_Types].xml")

    def get_rels(self) -> etree._Element:
        return self.get_xml("word/_rels/document.xml.rels")

    def list_entries(self):
        if self._zip is None:
            return []
        return self._zip.namelist()

    def read_binary(self, name: str) -> bytes:
        if self._zip is None:
            raise RuntimeError("Reader not opened")
        return self._zip.read(name)
