"""Configuration loader - reads config.yaml and provides typed settings."""

import os
import secrets
from pathlib import Path
from typing import List, Optional

import yaml
from pydantic import BaseModel, Field


class ServerConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1


class CeleryConfig(BaseModel):
    concurrency: int = 4
    broker_url: str = "redis://localhost:6379/0"
    result_backend: str = "redis://localhost:6379/1"


class StorageConfig(BaseModel):
    base_path: str = "./storage"
    max_file_size_mb: int = 100
    max_batch_size: int = 500
    temp_retention_hours: int = 24
    original_retention_days: int = 30


class DatabaseConfig(BaseModel):
    url: str = "sqlite:///./data/app.db"


class SecurityConfig(BaseModel):
    jwt_secret: str = ""
    jwt_expire_minutes: int = 1440
    cors_origins: List[str] = Field(default_factory=lambda: ["http://localhost:8000"])


class LoggingConfig(BaseModel):
    level: str = "INFO"
    file: str = "./logs/app.log"
    max_size_mb: int = 50
    backup_count: int = 10


class PreviewConfig(BaseModel):
    refresh_debounce_ms: int = 150
    max_render_pages: int = 50


class AppConfig(BaseModel):
    server: ServerConfig = Field(default_factory=ServerConfig)
    celery: CeleryConfig = Field(default_factory=CeleryConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    preview: PreviewConfig = Field(default_factory=PreviewConfig)


def load_config(config_path: Optional[str] = None) -> AppConfig:
    """Load configuration from YAML file."""
    if config_path is None:
        config_path = os.environ.get("APP_CONFIG", "./config.yaml")

    path = Path(config_path)
    if path.exists():
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    else:
        data = {}

    config = AppConfig(**data)

    # Auto-generate JWT secret if empty
    if not config.security.jwt_secret:
        config.security.jwt_secret = secrets.token_urlsafe(48)

    return config


# Singleton config instance
_config: Optional[AppConfig] = None


def get_config() -> AppConfig:
    global _config
    if _config is None:
        _config = load_config()
    return _config
