"""Database setup - SQLAlchemy engine, session, and base."""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

from typing import Optional

from backend.config import get_config


class Base(DeclarativeBase):
    pass


def get_engine(url: Optional[str] = None):
    if url is None:
        url = get_config().database.url
    return create_engine(url, echo=False, connect_args={"check_same_thread": False})


def get_session_factory(engine=None):
    if engine is None:
        engine = get_engine()
    return sessionmaker(bind=engine, autocommit=False, autoflush=False)


SessionLocal = None


def init_db():
    """Initialize database and create all tables."""
    global SessionLocal
    engine = get_engine()
    SessionLocal = get_session_factory(engine)

    # Import all models to register them
    from backend.models import user, document, template, task, log_entry  # noqa: F401

    Base.metadata.create_all(bind=engine)
    return engine


def get_db():
    """FastAPI dependency for database sessions."""
    if SessionLocal is None:
        init_db()
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
