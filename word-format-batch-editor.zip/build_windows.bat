@echo off
echo === Building Frontend ===
cd frontend
call npm ci
call npm run build
cd ..

echo === Building Backend Server ===
pyinstaller --noconfirm --onedir --name server ^
  --add-data "frontend/dist;frontend/dist" ^
  --hidden-import uvicorn.logging ^
  --hidden-import uvicorn.loops ^
  --hidden-import uvicorn.loops.auto ^
  --hidden-import uvicorn.protocols ^
  --hidden-import uvicorn.protocols.http ^
  --hidden-import uvicorn.protocols.http.auto ^
  --hidden-import uvicorn.protocols.websockets ^
  --hidden-import uvicorn.protocols.websockets.auto ^
  --hidden-import uvicorn.lifespan ^
  --hidden-import uvicorn.lifespan.on ^
  backend/main.py

echo === Building Celery Worker ===
pyinstaller --noconfirm --onedir --name worker ^
  --hidden-import celery ^
  --hidden-import celery.concurrency.solo ^
  backend/worker_entry.py

echo === Packaging Redis ===
mkdir dist\WordFormatEditor\redis
copy redis-windows\redis-server.exe dist\WordFormatEditor\redis\
copy redis-windows\redis.conf dist\WordFormatEditor\redis\

echo === Copying Config & Scripts ===
copy config.yaml dist\WordFormatEditor\
copy start.bat dist\WordFormatEditor\
copy stop.bat dist\WordFormatEditor\

echo === Build Complete ===
echo Output: dist\WordFormatEditor\
