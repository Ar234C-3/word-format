# Word Format Batch Editor

## 项目简介

Web-based批量Word文档格式处理器，支持结构感知编辑。

## 技术栈

- **后端**: FastAPI + Celery + Redis + SQLite + python-docx + lxml
- **前端**: Vue 3 + Element Plus + Vite + Pinia

## 快速开始

### 开发环境

```bash
# 后端
pip install -r requirements.txt
python -m backend.main

# 前端
cd frontend
npm install
npm run dev
```

### Windows便携部署

```bash
# 构建
build_windows.bat

# 运行
cd dist/WordFormatEditor
start.bat
```

## 目录结构

```
├── backend/          # Python后端
│   ├── api/          # API路由
│   ├── core/         # OOXML底层操作
│   ├── models/       # SQLAlchemy模型
│   ├── schemas/      # Pydantic模型
│   ├── services/     # 业务逻辑
│   ├── tasks/        # Celery任务
│   └── utils/        # 工具函数
├── frontend/         # Vue 3前端
├── config.yaml       # 配置文件
├── start.bat         # Windows启动脚本
└── stop.bat          # Windows停止脚本
```
