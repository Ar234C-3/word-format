@echo off
chcp 65001 >nul
echo [INFO] Stopping Word Format Batch Editor...

:: 停止FastAPI
taskkill /f /im server.exe >nul 2>&1
:: 停止Celery Worker
taskkill /f /im worker.exe >nul 2>&1
:: 停止Redis
taskkill /f /im redis-server.exe >nul 2>&1

echo [INFO] All services stopped.
pause
