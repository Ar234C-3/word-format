import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/', component: () => import('../views/Dashboard.vue') },
  { path: '/documents', component: () => import('../views/DocumentList.vue') },
  { path: '/editor/:docId', component: () => import('../views/Editor.vue') },
  { path: '/tasks', component: () => import('../views/TaskList.vue') },
  { path: '/tasks/:taskId', component: () => import('../views/TaskDetail.vue') },
  { path: '/templates', component: () => import('../views/TemplateManager.vue') },
  { path: '/logs', component: () => import('../views/LogViewer.vue') },
  { path: '/settings', component: () => import('../views/Settings.vue') },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
