<template>
  <div class="log-viewer">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>日志查看器</span>
          <div>
            <el-button size="small" @click="exportLogs('json')">导出JSON</el-button>
            <el-button size="small" @click="exportLogs('csv')">导出CSV</el-button>
          </div>
        </div>
      </template>

      <!-- Filters -->
      <el-form :inline="true" size="small" style="margin-bottom: 16px;">
        <el-form-item label="级别">
          <el-select v-model="filters.level" clearable placeholder="全部">
            <el-option label="DEBUG" value="DEBUG" />
            <el-option label="INFO" value="INFO" />
            <el-option label="WARN" value="WARN" />
            <el-option label="ERROR" value="ERROR" />
            <el-option label="FATAL" value="FATAL" />
          </el-select>
        </el-form-item>
        <el-form-item label="操作">
          <el-input v-model="filters.action" placeholder="操作类型" clearable />
        </el-form-item>
        <el-form-item label="文档ID">
          <el-input v-model="filters.document" placeholder="文档ID" clearable />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="fetchLogs">查询</el-button>
        </el-form-item>
      </el-form>

      <!-- Log Table -->
      <el-table :data="logs" v-loading="loading" stripe size="small" max-height="500">
        <el-table-column prop="timestamp" label="时间" width="180" />
        <el-table-column prop="level" label="级别" width="80">
          <template #default="{ row }">
            <el-tag :type="levelType(row.level)" size="small">{{ row.level }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="action" label="操作" width="120" />
        <el-table-column prop="document_id" label="文档ID" width="280" show-overflow-tooltip />
        <el-table-column prop="message" label="消息" min-width="200" show-overflow-tooltip />
        <el-table-column label="变更" width="200">
          <template #default="{ row }">
            <span v-if="row.before_value !== null" style="color: #f56c6c;">{{ JSON.stringify(row.before_value) }}</span>
            <span v-if="row.after_value !== null"> → </span>
            <span v-if="row.after_value !== null" style="color: #67c23a;">{{ JSON.stringify(row.after_value) }}</span>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="page"
        :page-size="50"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="fetchLogs"
        style="margin-top: 16px;"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const logs = ref([])
const loading = ref(false)
const page = ref(1)
const total = ref(0)
const filters = ref({ level: '', action: '', document: '' })

const levelType = (l) => ({ DEBUG: 'info', INFO: '', WARN: 'warning', ERROR: 'danger', FATAL: 'danger' }[l] || 'info')

const fetchLogs = async () => {
  loading.value = true
  try {
    const params = { page: page.value, size: 50 }
    if (filters.value.level) params.level = filters.value.level
    if (filters.value.action) params.action = filters.value.action
    if (filters.value.document) params.document = filters.value.document
    const res = await api.get('/logs', { params })
    logs.value = res.data?.items || []
    total.value = res.data?.total || 0
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

const exportLogs = (format) => {
  const params = new URLSearchParams({ format })
  if (filters.value.level) params.set('level', filters.value.level)
  if (filters.value.action) params.set('action', filters.value.action)
  window.open(`/api/v1/logs/export?${params}`, '_blank')
}

onMounted(fetchLogs)
</script>

<style scoped>
.log-viewer { max-width: 1200px; margin: 0 auto; }
</style>
