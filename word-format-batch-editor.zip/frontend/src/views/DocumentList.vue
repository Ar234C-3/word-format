<template>
  <div class="document-list">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>文档管理</span>
          <el-upload
            action="/api/v1/documents/upload"
            :on-success="onUpload"
            :show-file-list="false"
            accept=".docx"
            multiple
          >
            <el-button type="primary">上传文档</el-button>
          </el-upload>
        </div>
      </template>

      <el-table :data="documents" v-loading="loading" stripe>
        <el-table-column prop="name" label="文件名" min-width="200" />
        <el-table-column label="大小" width="100">
          <template #default="{ row }">{{ formatSize(row.size) }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" size="small">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="$router.push(`/editor/${row.id}`)">编辑</el-button>
            <el-button size="small" type="success" link @click="downloadDoc(row.id)">下载</el-button>
            <el-button size="small" type="danger" link @click="deleteDoc(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="page"
        :page-size="pageSize"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="fetchDocs"
        style="margin-top: 16px; justify-content: flex-end;"
      />
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '../api'

const documents = ref([])
const loading = ref(false)
const page = ref(1)
const pageSize = ref(20)
const total = ref(0)

const statusType = (s) => ({ UPLOADED: 'info', PROCESSING: 'warning', DONE: 'success', ERROR: 'danger', SKIPPED: 'info' }[s] || 'info')

const formatSize = (bytes) => {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

const fetchDocs = async () => {
  loading.value = true
  try {
    const res = await api.get('/documents', { params: { page: page.value, size: pageSize.value } })
    documents.value = res.data?.items || []
    total.value = res.data?.total || 0
  } catch (e) {
    ElMessage.error('加载失败: ' + e.message)
  } finally {
    loading.value = false
  }
}

const onUpload = (res) => {
  ElMessage.success('上传成功')
  fetchDocs()
}

const downloadDoc = (id) => {
  window.open(`/api/v1/documents/${id}/download`, '_blank')
}

const deleteDoc = async (id) => {
  await ElMessageBox.confirm('确定删除此文档？', '确认')
  try {
    await api.delete(`/documents/${id}`)
    ElMessage.success('已删除')
    fetchDocs()
  } catch (e) {
    ElMessage.error('删除失败')
  }
}

onMounted(fetchDocs)
</script>

<style scoped>
.document-list { max-width: 1000px; margin: 0 auto; }
</style>
