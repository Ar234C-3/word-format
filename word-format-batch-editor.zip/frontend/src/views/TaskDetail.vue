<template>
  <div class="task-detail" v-loading="loading">
    <el-page-header @back="$router.back()" style="margin-bottom: 16px;">
      <template #content>{{ task?.name || '任务详情' }}</template>
    </el-page-header>

    <el-row :gutter="20" v-if="task">
      <el-col :span="16">
        <el-card>
          <template #header>任务状态</template>
          <el-descriptions :column="2" border>
            <el-descriptions-item label="状态">
              <el-tag :type="statusType(task.status)">{{ task.status }}</el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="进度">
              <el-progress :percentage="Math.round(task.progress * 100)" />
            </el-descriptions-item>
            <el-descriptions-item label="总文档数">{{ task.total_documents }}</el-descriptions-item>
            <el-descriptions-item label="已处理">{{ task.processed_documents }}</el-descriptions-item>
            <el-descriptions-item label="成功">{{ task.success_count }}</el-descriptions-item>
            <el-descriptions-item label="错误">{{ task.error_count }}</el-descriptions-item>
            <el-descriptions-item label="跳过">{{ task.skipped_count }}</el-descriptions-item>
            <el-descriptions-item label="创建时间">{{ task.created_at }}</el-descriptions-item>
            <el-descriptions-item label="开始时间">{{ task.started_at || '-' }}</el-descriptions-item>
            <el-descriptions-item label="完成时间">{{ task.completed_at || '-' }}</el-descriptions-item>
          </el-descriptions>

          <div style="margin-top: 16px;" v-if="task.error_message">
            <el-alert :title="task.error_message" type="error" show-icon />
          </div>

          <div style="margin-top: 16px;">
            <el-button v-if="task.status === 'RUNNING'" type="warning" @click="pause">暂停</el-button>
            <el-button v-if="task.status === 'PAUSED'" type="success" @click="resume">恢复</el-button>
            <el-button v-if="['PENDING','RUNNING','PAUSED'].includes(task.status)" type="danger" @click="cancel">取消</el-button>
            <el-button v-if="['DONE','FAILED'].includes(task.status)" @click="rollback">回滚</el-button>
            <el-button @click="viewDiff">查看Diff</el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :span="8">
        <el-card>
          <template #header>实时日志</template>
          <div class="log-area" ref="logArea">
            <div v-for="(log, i) in logs" :key="i" class="log-line" :class="log.level?.toLowerCase()">
              [{{ log.timestamp }}] {{ log.message }}
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import api from '../api'

const route = useRoute()
const taskId = route.params.taskId
const task = ref(null)
const loading = ref(false)
const logs = ref([])
let ws = null

const statusType = (s) => ({ PENDING: 'info', RUNNING: 'warning', DONE: 'success', FAILED: 'danger', PAUSED: '', CANCELLED: 'info' }[s] || 'info')

const fetchTask = async () => {
  loading.value = true
  try {
    const res = await api.get(`/tasks/${taskId}`)
    task.value = res.data
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

const pause = async () => { await api.put(`/tasks/${taskId}/pause`); fetchTask() }
const resume = async () => { await api.put(`/tasks/${taskId}/resume`); fetchTask() }
const cancel = async () => { await api.delete(`/tasks/${taskId}`); fetchTask() }
const rollback = async () => { await api.post(`/tasks/${taskId}/rollback`, []); ElMessage.success('已回滚') }
const viewDiff = async () => {
  try {
    const res = await api.get(`/tasks/${taskId}/diff`)
    console.log('Diff:', res.data)
    ElMessage.info('Diff数据已加载，请查看控制台')
  } catch (e) {
    ElMessage.error('获取Diff失败')
  }
}

function connectWS() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:'
  ws = new WebSocket(`${protocol}//${location.host}/ws/v1/progress?task_id=${taskId}`)
  ws.onmessage = (e) => {
    try {
      const data = JSON.parse(e.data)
      logs.value.push(data)
      if (data.progress !== undefined && task.value) {
        task.value.progress = data.progress
      }
    } catch {}
  }
  ws.onclose = () => { setTimeout(connectWS, 3000) }
}

onMounted(() => { fetchTask(); connectWS() })
onUnmounted(() => { ws?.close() })
</script>

<style scoped>
.task-detail { max-width: 1200px; margin: 0 auto; }
.log-area { max-height: 400px; overflow-y: auto; font-family: monospace; font-size: 12px; background: #1e1e1e; color: #d4d4d4; padding: 8px; border-radius: 4px; }
.log-line { padding: 2px 0; }
.log-line.error { color: #f44747; }
.log-line.warn { color: #cca700; }
.log-line.info { color: #4ec9b0; }
</style>
