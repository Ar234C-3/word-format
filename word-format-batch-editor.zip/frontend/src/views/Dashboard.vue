<template>
  <div class="dashboard">
    <el-row :gutter="20" class="stat-row">
      <el-col :span="6">
        <el-card shadow="hover">
          <template #header>📄 文档总数</template>
          <div class="stat-value">{{ stats.documents }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <template #header>✅ 已处理</template>
          <div class="stat-value">{{ stats.processed }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <template #header>📋 批量任务</template>
          <div class="stat-value">{{ stats.tasks }}</div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card shadow="hover">
          <template #header>📑 模板数</template>
          <div class="stat-value">{{ stats.templates }}</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="12">
        <el-card>
          <template #header>最近文档</template>
          <el-table :data="recentDocs" size="small" max-height="300">
            <el-table-column prop="name" label="文件名" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="{ row }">
                <el-tag :type="statusType(row.status)" size="small">{{ row.status }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="80">
              <template #default="{ row }">
                <el-button size="small" type="primary" link @click="$router.push(`/editor/${row.id}`)">编辑</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <template #header>最近任务</template>
          <el-table :data="recentTasks" size="small" max-height="300">
            <el-table-column prop="name" label="任务名" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="{ row }">
                <el-tag :type="taskStatusType(row.status)" size="small">{{ row.status }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="进度" width="120">
              <template #default="{ row }">
                <el-progress :percentage="Math.round(row.progress * 100)" :stroke-width="6" />
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import api from '../api'

const stats = ref({ documents: 0, processed: 0, tasks: 0, templates: 0 })
const recentDocs = ref([])
const recentTasks = ref([])

const statusType = (s) => ({ UPLOADED: 'info', PROCESSING: 'warning', DONE: 'success', ERROR: 'danger' }[s] || 'info')
const taskStatusType = (s) => ({ PENDING: 'info', RUNNING: 'warning', DONE: 'success', FAILED: 'danger', PAUSED: '', CANCELLED: 'info' }[s] || 'info')

onMounted(async () => {
  try {
    const [docs, tasks, templates] = await Promise.all([
      api.get('/documents', { params: { size: 5 } }),
      api.get('/tasks', { params: { size: 5 } }),
      api.get('/templates'),
    ])
    stats.value.documents = docs.data?.total || 0
    stats.value.processed = (docs.data?.items || []).filter(d => d.status === 'DONE').length
    stats.value.tasks = tasks.data?.total || 0
    stats.value.templates = (templates.data || []).length
    recentDocs.value = docs.data?.items || []
    recentTasks.value = tasks.data?.items || []
  } catch (e) {
    console.error(e)
  }
})
</script>

<style scoped>
.dashboard { max-width: 1200px; margin: 0 auto; }
.stat-value { font-size: 36px; font-weight: bold; color: #409eff; text-align: center; padding: 10px 0; }
</style>
