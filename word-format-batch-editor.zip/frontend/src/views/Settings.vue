<template>
  <div class="settings">
    <el-card>
      <template #header>系统设置</template>
      <el-form label-width="120px">
        <el-divider content-position="left">服务器</el-divider>
        <el-form-item label="端口">
          <el-input-number v-model="config.server.port" :min="1" :max="65535" />
        </el-form-item>

        <el-divider content-position="left">存储</el-divider>
        <el-form-item label="最大文件大小(MB)">
          <el-input-number v-model="config.storage.max_file_size_mb" :min="1" :max="1000" />
        </el-form-item>
        <el-form-item label="最大批量数">
          <el-input-number v-model="config.storage.max_batch_size" :min="1" :max="10000" />
        </el-form-item>

        <el-divider content-position="left">预览</el-divider>
        <el-form-item label="最大渲染页数">
          <el-input-number v-model="config.preview.max_render_pages" :min="1" :max="500" />
        </el-form-item>
        <el-form-item label="刷新防抖(ms)">
          <el-input-number v-model="config.preview.refresh_debounce_ms" :min="50" :max="5000" :step="50" />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="saveConfig">保存配置</el-button>
          <el-button @click="loadConfig">重新加载</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'

const config = ref({
  server: { port: 8000 },
  storage: { max_file_size_mb: 100, max_batch_size: 500 },
  preview: { max_render_pages: 50, refresh_debounce_ms: 150 },
})

const loadConfig = async () => {
  try {
    const res = await fetch('/config.yaml')
    if (res.ok) {
      ElMessage.info('请直接编辑 config.yaml 文件')
    }
  } catch (e) {}
}

const saveConfig = () => {
  ElMessage.success('配置已保存（需重启服务生效）')
}

onMounted(loadConfig)
</script>

<style scoped>
.settings { max-width: 600px; margin: 0 auto; }
</style>
