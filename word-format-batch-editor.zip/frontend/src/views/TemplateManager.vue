<template>
  <div class="template-manager">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>模板管理</span>
          <el-button type="primary" @click="openCreate">新建模板</el-button>
        </div>
      </template>

      <el-table :data="templates" v-loading="loading" stripe>
        <el-table-column prop="name" label="模板名" min-width="200" />
        <el-table-column prop="description" label="描述" min-width="200" />
        <el-table-column label="规则数" width="100">
          <template #default="{ row }">{{ (row.format_rules || []).length }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="editTemplate(row)">编辑</el-button>
            <el-button size="small" type="danger" link @click="deleteTemplate(row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- Create/Edit Dialog -->
    <el-dialog v-model="showDialog" :title="editingId ? '编辑模板' : '新建模板'" width="700px">
      <el-form label-width="100px">
        <el-form-item label="模板名称">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="form.description" type="textarea" :rows="2" />
        </el-form-item>
        <el-form-item label="格式规则">
          <el-button size="small" @click="addRule">添加规则</el-button>
          <div v-for="(rule, i) in form.format_rules" :key="i" style="margin-top: 8px; border: 1px solid #e4e7ed; padding: 12px; border-radius: 4px;">
            <el-row :gutter="10">
              <el-col :span="8">
                <el-input v-model="rule.name" placeholder="规则名称" size="small" />
              </el-col>
              <el-col :span="8">
                <el-select v-model="rule.condition.node_type" placeholder="节点类型" size="small" clearable>
                  <el-option label="标题" value="heading" />
                  <el-option label="段落" value="paragraph" />
                  <el-option label="表格" value="table" />
                  <el-option label="列表项" value="list_item" />
                </el-select>
              </el-col>
              <el-col :span="8">
                <el-input-number v-model="rule.priority" placeholder="优先级" size="small" />
              </el-col>
            </el-row>
            <el-row :gutter="10" style="margin-top: 8px;">
              <el-col :span="6">
                <el-input v-model="rule.action.font_cn" placeholder="中文字体" size="small" />
              </el-col>
              <el-col :span="6">
                <el-input-number v-model="rule.action.font_size" placeholder="字号" size="small" :min="6" :max="72" />
              </el-col>
              <el-col :span="6">
                <el-color-picker v-model="rule.action.font_color" size="small" />
              </el-col>
              <el-col :span="6">
                <el-button size="small" type="danger" text @click="form.format_rules.splice(i, 1)">删除</el-button>
              </el-col>
            </el-row>
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="saveTemplate">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import api from '../api'

const templates = ref([])
const loading = ref(false)
const showDialog = ref(false)
const editingId = ref(null)
const form = ref({ name: '', description: '', format_rules: [] })

const fetchTemplates = async () => {
  loading.value = true
  try {
    const res = await api.get('/templates')
    templates.value = res.data || []
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

const openCreate = () => {
  editingId.value = null
  form.value = { name: '', description: '', format_rules: [] }
  showDialog.value = true
}

const editTemplate = (t) => {
  editingId.value = t.id
  form.value = { name: t.name, description: t.description, format_rules: [...(t.format_rules || [])] }
  showDialog.value = true
}

const addRule = () => {
  form.value.format_rules.push({
    id: `rule_${Date.now()}`, name: '', priority: 0, enabled: true,
    condition: { node_type: null },
    action: { font_cn: null, font_size: null, font_color: null },
  })
}

const saveTemplate = async () => {
  try {
    if (editingId.value) {
      await api.put(`/templates/${editingId.value}`, form.value)
    } else {
      await api.post('/templates', form.value)
    }
    ElMessage.success('已保存')
    showDialog.value = false
    fetchTemplates()
  } catch (e) {
    ElMessage.error('保存失败')
  }
}

const deleteTemplate = async (id) => {
  await ElMessageBox.confirm('确定删除？', '确认')
  await api.delete(`/templates/${id}`)
  fetchTemplates()
}

onMounted(fetchTemplates)
</script>

<style scoped>
.template-manager { max-width: 1000px; margin: 0 auto; }
</style>
