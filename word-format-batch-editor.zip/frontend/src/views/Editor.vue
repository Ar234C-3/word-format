<template>
  <div class="editor-page" v-loading="loading">
    <el-page-header @back="$router.back()" style="margin-bottom: 16px;">
      <template #content>
        <span>{{ document?.name || '文档编辑' }}</span>
      </template>
      <template #extra>
        <el-button type="primary" @click="saveConfig">保存配置</el-button>
        <el-button @click="dryRun">Dry-Run</el-button>
        <el-button type="success" @click="executeProcess">执行处理</el-button>
      </template>
    </el-page-header>

    <div class="editor-layout">
      <!-- Left: Structure Tree -->
      <div class="panel-left" :class="{ collapsed: !showTree }">
        <div class="panel-header">
          <span>结构树</span>
          <el-button size="small" text @click="showTree = !showTree">
            <el-icon><Fold /></el-icon>
          </el-button>
        </div>
        <div class="panel-body" v-show="showTree">
          <el-input v-model="searchText" placeholder="搜索..." size="small" clearable style="margin-bottom: 8px;" />
          <el-tree
            :data="treeData"
            :props="{ label: 'label', children: 'children' }"
            highlight-current
            @node-click="onNodeClick"
            default-expand-all
            :filter-node-method="filterNode"
            ref="treeRef"
          />
        </div>
      </div>

      <!-- Center: Preview -->
      <div class="panel-center">
        <div class="panel-header">
          <span>预览</span>
          <div>
            <el-slider v-model="zoom" :min="50" :max="200" :step="10" style="width: 120px; display: inline-block;" />
            <span style="margin-left: 8px;">{{ zoom }}%</span>
          </div>
        </div>
        <div class="preview-area" :style="{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }">
          <div v-if="previewHtml" v-html="previewHtml" class="preview-content"></div>
          <el-empty v-else description="上传文档后查看预览" />
        </div>
      </div>

      <!-- Right: Properties Panel -->
      <div class="panel-right" :class="{ collapsed: !showProps }">
        <div class="panel-header">
          <span>属性配置</span>
          <el-button size="small" text @click="showProps = !showProps">
            <el-icon><Fold /></el-icon>
          </el-button>
        </div>
        <div class="panel-body" v-show="showProps">
          <el-form label-width="80px" size="small" v-if="selectedNode">
            <el-divider content-position="left">字体</el-divider>
            <el-form-item label="中文字体">
              <el-input v-model="nodeFormat.font_cn" />
            </el-form-item>
            <el-form-item label="英文字体">
              <el-input v-model="nodeFormat.font_en" />
            </el-form-item>
            <el-form-item label="字号">
              <el-input-number v-model="nodeFormat.font_size" :min="6" :max="72" :step="0.5" />
            </el-form-item>
            <el-form-item label="颜色">
              <el-color-picker v-model="nodeFormat.font_color" />
            </el-form-item>
            <el-form-item label="加粗">
              <el-switch v-model="nodeFormat.bold" />
            </el-form-item>
            <el-form-item label="斜体">
              <el-switch v-model="nodeFormat.italic" />
            </el-form-item>
            <el-form-item label="下划线">
              <el-select v-model="nodeFormat.underline" clearable>
                <el-option label="单线" value="single" />
                <el-option label="双线" value="double" />
                <el-option label="波浪线" value="wave" />
              </el-select>
            </el-form-item>

            <el-divider content-position="left">段落</el-divider>
            <el-form-item label="对齐">
              <el-select v-model="nodeFormat.alignment" clearable>
                <el-option label="左对齐" value="left" />
                <el-option label="居中" value="center" />
                <el-option label="右对齐" value="right" />
                <el-option label="两端对齐" value="justify" />
              </el-select>
            </el-form-item>
            <el-form-item label="行距">
              <el-input-number v-model="nodeFormat.line_spacing" :min="0.5" :max="5" :step="0.25" />
            </el-form-item>
            <el-form-item label="段前距">
              <el-input-number v-model="nodeFormat.space_before" :min="0" :max="100" :step="6" />
            </el-form-item>
            <el-form-item label="段后距">
              <el-input-number v-model="nodeFormat.space_after" :min="0" :max="100" :step="6" />
            </el-form-item>
            <el-form-item label="首行缩进">
              <el-input-number v-model="nodeFormat.first_line_indent" :min="0" :max="100" :step="6" />
            </el-form-item>
          </el-form>
          <el-empty v-else description="点击结构树节点查看属性" />
        </div>
      </div>
    </div>

    <!-- Status Bar -->
    <div class="status-bar">
      <span>{{ selectedNode ? `选中: ${selectedNode.type} - ${selectedNode.content_preview}` : '未选中节点' }}</span>
      <span>缩放: {{ zoom }}%</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Fold } from '@element-plus/icons-vue'
import api from '../api'

const route = useRoute()
const docId = route.params.docId

const loading = ref(false)
const document = ref(null)
const structure = ref(null)
const previewHtml = ref('')
const zoom = ref(100)
const searchText = ref('')
const showTree = ref(true)
const showProps = ref(true)
const selectedNode = ref(null)
const nodeFormat = ref({})
const treeRef = ref(null)

const treeData = computed(() => {
  if (!structure.value) return []
  const nodes = structure.value.nodes
  const rootIds = structure.value.root_node_ids || []
  return buildTree(rootIds, nodes)
})

function buildTree(ids, nodes) {
  return ids.map(id => {
    const node = nodes[id]
    if (!node) return null
    const label = node.type === 'heading' ? `${'#'.repeat(node.level)} ${node.content_preview}` :
                  node.type === 'table' ? node.content_preview :
                  node.content_preview || `[${node.type}]`
    const children = (node.children_ids || []).length > 0 ? buildTree(node.children_ids, nodes) : []
    return { id, label, node, children }
  }).filter(Boolean)
}

function filterNode(value, data) {
  if (!value) return true
  return data.label.toLowerCase().includes(value.toLowerCase())
}

watch(searchText, (val) => {
  treeRef.value?.filter(val)
})

function onNodeClick(data) {
  selectedNode.value = data.node
  nodeFormat.value = { ...data.node.current_format }
}

async function loadDocument() {
  loading.value = true
  try {
    const [structRes, previewRes] = await Promise.all([
      api.get(`/documents/${docId}/structure`),
      api.get(`/documents/${docId}/preview`),
    ])
    structure.value = structRes.data
    previewHtml.value = previewRes.data?.html || ''
  } catch (e) {
    ElMessage.error('加载文档失败: ' + e.message)
  } finally {
    loading.value = false
  }
}

function saveConfig() {
  ElMessage.success('配置已保存')
}

async function dryRun() {
  try {
    const res = await api.post('/tasks/dry-run', {
      document_ids: [docId],
      rules: [],
    })
    ElMessage.info(`Dry-Run: ${res.data?.would_modify || 0} 个文档将被修改`)
  } catch (e) {
    ElMessage.error('Dry-Run 失败')
  }
}

async function executeProcess() {
  try {
    const res = await api.post('/tasks', {
      document_ids: [docId],
      rules: [],
    })
    ElMessage.success(`任务已创建: ${res.data?.task_id}`)
  } catch (e) {
    ElMessage.error('执行失败')
  }
}

onMounted(loadDocument)
</script>

<style scoped>
.editor-page { height: calc(100vh - 140px); display: flex; flex-direction: column; }
.editor-layout { display: flex; flex: 1; gap: 4px; overflow: hidden; }
.panel-left { width: 240px; background: #fff; border-radius: 4px; border: 1px solid #e4e7ed; display: flex; flex-direction: column; transition: width 0.3s; }
.panel-left.collapsed { width: 0; overflow: hidden; }
.panel-center { flex: 1; background: #fff; border-radius: 4px; border: 1px solid #e4e7ed; display: flex; flex-direction: column; overflow: hidden; }
.panel-right { width: 320px; background: #fff; border-radius: 4px; border: 1px solid #e4e7ed; display: flex; flex-direction: column; transition: width 0.3s; overflow-y: auto; }
.panel-right.collapsed { width: 0; overflow: hidden; }
.panel-header { padding: 8px 12px; font-weight: bold; border-bottom: 1px solid #e4e7ed; display: flex; justify-content: space-between; align-items: center; }
.panel-body { padding: 12px; flex: 1; overflow-y: auto; }
.preview-area { flex: 1; padding: 20px; overflow: auto; }
.preview-content { max-width: 800px; margin: 0 auto; }
.status-bar { padding: 4px 12px; background: #f5f7fa; border-top: 1px solid #e4e7ed; display: flex; justify-content: space-between; font-size: 12px; color: #909399; }
</style>
