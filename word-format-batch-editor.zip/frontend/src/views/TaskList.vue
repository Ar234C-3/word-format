<template>
  <div class="task-list">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>批量任务管理</span>
          <el-button type="primary" @click="showCreate = true">新建任务</el-button>
        </div>
      </template>

      <el-table :data="tasks" v-loading="loading" stripe>
        <el-table-column prop="name" label="任务名" min-width="200" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusType(row.status)" size="small">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="进度" width="200">
          <template #default="{ row }">
            <el-progress :percentage="Math.round(row.progress * 100)" :stroke-width="8" />
            <span style="font-size: 12px; color: #909399;">{{ row.processed_documents }}/{{ row.total_documents }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250">
          <template #default="{ row }">
            <el-button size="small" type="primary" link @click="$router.push(`/tasks/${row.id}`)">详情</el-button>
            <el-button v-if="row.status === 'RUNNING'" size="small" type="warning" link @click="pauseTask(row.id)">暂停</el-button>
            <el-button v-if="row.status === 'PAUSED'" size="small" type="success" link @click="resumeTask(row.id)">恢复</el-button>
            <el-button v-if="['PENDING','RUNNING','PAUSED'].includes(row.status)" size="small" type="danger" link @click="cancelTask(row.id)">取消</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        v-model:current-page="page"
        :page-size="20"
        :total="total"
        layout="total, prev, pager, next"
        @current-change="fetchTasks"
        style="margin-top: 16px;"
      />
    </el-card>

    <!-- Create Task Dialog -->
    <el-dialog v-model="showCreate" title="新建批量任务" width="600px">
      <el-form label-width="100px">
        <el-form-item label="任务名称">
          <el-input v-model="newTask.name" />
        </el-form-item>
        <el-form-item label="选择文档">
          <el-select v-model="newTask.document_ids" multiple placeholder="选择文档" style="width: 100%;">
            <el-option v-for="d in availableDocs" :key="d.id" :label="d.name" :value="d.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showCreate = false">取消</el-button>
        <el-button @click="runDryRun">Dry-Run</el-button>
        <el-button type="primary" @click="createTask">创建并执行</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import api from '../api'

const tasks = ref([])
const loading = ref(false)
const page = ref(1)
const total = ref(0)
const showCreate = ref(false)
const availableDocs = ref([])
const newTask = ref({ name: '', document_ids: [], rules: [] })

const statusType = (s) => ({ PENDING: 'info', RUNNING: 'warning', DONE: 'success', FAILED: 'danger', PAUSED: '', CANCELLED: 'info' }[s] || 'info')

const fetchTasks = async () => {
  loading.value = true
  try {
    const res = await api.get('/tasks', { params: { page: page.value, size: 20 } })
    tasks.value = res.data?.items || []
    total.value = res.data?.total || 0
  } catch (e) {
    ElMessage.error('加载失败')
  } finally {
    loading.value = false
  }
}

const fetchDocs = async () => {
  try {
    const res = await api.get('/documents', { params: { size: 100 } })
    availableDocs.value = res.data?.items || []
  } catch (e) {}
}

const createTask = async () => {
  if (!newTask.value.document_ids.length) {
    ElMessage.warning('请选择至少一个文档')
    return
  }
  try {
    await api.post('/tasks', newTask.value)
    ElMessage.success('任务已创建')
    showCreate.value = false
    fetchTasks()
  } catch (e) {
    ElMessage.error('创建失败')
  }
}

const runDryRun = async () => {
  if (!newTask.value.document_ids.length) {
    ElMessage.warning('请选择至少一个文档')
    return
  }
  try {
    const res = await api.post('/tasks/dry-run', newTask.value)
    ElMessage.info(`Dry-Run: ${res.data?.would_modify || 0} 将修改, ${res.data?.would_skip || 0} 无变化, ${res.data?.would_error || 0} 错误`)
  } catch (e) {
    ElMessage.error('Dry-Run 失败')
  }
}

const pauseTask = async (id) => {
  await api.put(`/tasks/${id}/pause`)
  fetchTasks()
}

const resumeTask = async (id) => {
  await api.put(`/tasks/${id}/resume`)
  fetchTasks()
}

const cancelTask = async (id) => {
  await api.delete(`/tasks/${id}`)
  fetchTasks()
}

onMounted(() => { fetchTasks(); fetchDocs() })
</script>

<style scoped>
.task-list { max-width: 1000px; margin: 0 auto; }
</style>
