<template>
  <el-container class="app-container">
    <el-header class="app-header">
      <div class="header-left">
        <h1 class="logo">📝 Word Format Batch Editor</h1>
      </div>
      <el-menu
        :default-active="$route.path"
        mode="horizontal"
        router
        class="header-menu"
      >
        <el-menu-item index="/">概览</el-menu-item>
        <el-menu-item index="/documents">文档管理</el-menu-item>
        <el-menu-item index="/tasks">批量任务</el-menu-item>
        <el-menu-item index="/templates">模板管理</el-menu-item>
        <el-menu-item index="/logs">日志</el-menu-item>
      </el-menu>
    </el-header>
    <el-main class="app-main">
      <router-view />
    </el-main>
  </el-container>
</template>

<script setup>
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Microsoft YaHei', sans-serif; background: #f5f7fa; }
.app-container { min-height: 100vh; }
.app-header {
  display: flex; align-items: center; background: #fff;
  box-shadow: 0 1px 4px rgba(0,0,0,0.08); padding: 0 20px; height: 60px;
}
.header-left { margin-right: 40px; }
.logo { font-size: 18px; color: #303133; white-space: nowrap; }
.header-menu { border-bottom: none; }
.app-main { padding: 20px; }
</style>
