@echo off
chcp 65001 >nul
title Word Format Batch Editor v1.0

:: 检查端口占用
netstat -ano | findstr ":8000" >nul && (
    echo [ERROR] Port 8000 is already in use. Please close other programs or edit config.yaml.
    pause
    exit /b 1
)

:: 启动Redis
echo [INFO] Starting Redis...
start /min "" "%~dp0redis\redis-server.exe" "%~dp0redis\redis.conf"
timeout /t 2 /nobreak >nul

:: 启动Celery Worker
echo [INFO] Starting Celery Worker...
start /min "" "%~dp0backend\worker.exe" --pool=solo --loglevel=info

:: 启动FastAPI Server
echo [INFO] Starting Web Server...
start /min "" "%~dp0backend\server.exe"

:: 等待服务就绪并打开浏览器
echo [INFO] Waiting for server to be ready...
:wait_loop
curl -s http://localhost:8000/api/v1/health >nul 2>&1
if errorlevel 1 (
    timeout /t 1 /nobreak >nul
    goto wait_loop
)

echo [INFO] Server is ready! Opening browser...
start http://localhost:8000
echo.
echo ========================================
echo   Word Format Batch Editor is running
echo   URL: http://localhost:8000
echo   Press Ctrl+C or run stop.bat to stop
echo ========================================
pause
